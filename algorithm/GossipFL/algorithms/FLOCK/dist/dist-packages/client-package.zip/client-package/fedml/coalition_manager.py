import logging
import numpy as np
from .utils import generate_bandwidth
from fedml_core.distributed.communication.message import Message

from utils.context import (
    raise_MPI_error,
    raise_error_without_process,
    get_lock,
)

from .message_define import MyMessage

from queue import Queue, Empty, Full
class CoalitionManager:
    def __init__(self, args, worker_index, size, bandwidth, bw_norm, outs):

        self.args = args
        self.worker_index = worker_index
        self.size = size
        
        self.round = 0
        self.epochs = 0
        self.num_iterations = 0

        # ---- HEDONIC 参数 ----
        self.bandwidth = bandwidth      # 0‑1 归一化带宽矩阵
        bw_raw = self.bandwidth[self.worker_index]     # 1-D
        self.bw_norm = bw_norm   # 0-1
        self.outs = outs
        self.util_cache = np.zeros(size)               # 邻居效用 EMA
        self.util_alpha = 0.2                          # EMA 衰减
        self.util_eps = 0.3                            # ε‑greedy
        self.lambda_bw0 = 3.0
        self.lambda_sim0 = 0.8
        self.lambda_dist = 0.05
        self.time_const = 1.0 * self.epochs
        # -------- 阈值 + 时间窗 --------
        self.util_threshold = 0.0
        self.target_good_ratio = 0.3
        self.tolerance_ratio = 0.05
        self.adjust_step = 0.002
        self.time_window = int(np.ceil(3 * np.log(size)))
        self.last_chosen_round = np.zeros(size, dtype=int)

        # -------- 缓存高/低分邻居集合 --------
        self.good_set = set()
        self.bad_set = set(range(size))

        self.PHASE1 = 0.04   # <15% : 全随机
        self.PHASE3 = 0.60   # >70% : 只


        # ====== Coalition (lazy gossip) state ======
        # 每节点标签（不维护全局 coalition_set）
        self.coalition_index: int = int(self.worker_index)
        self.coalition_ver:   int = 0

        # 仅缓存“邻居 -> (ci, ver, ts_local)”的最近观测（不跨节点比较 ts）
        self._neighbor_coal_cache = {}   # {nid: (ci, ver, ts)}
        self._coal_lock = get_lock(f"coalition-lock-{self.worker_index}")

        # 懒传播队列：存最近看到的 (member, ci, ver, ts)，piggyback 用
        from collections import deque
        self._coal_delta_q = deque(maxlen=128)
        self._coal_seen_delta = set()    # 去重键： (member, ver)

        # 本地单调计时（仅用于TTL/冷却，不对外传播）
        self._last_broadcast_tick = 0
        self._broadcast_min_interval_tick = 3  # 至少隔 3 次发送才带一批 deltas

        # —— 用于“只靠本地信息”的换盟阈值 —— 
        self._target_density = 0.3     # 目标“同盟邻居占比”，可按需调
        self._tau0 = 0.02              # 基础阈值
        self._beta = 0.05              # 拥挤惩罚系数（dens_i > target 时降低 τ，促进离开）
    

    # ---------- Coalition helpers ----------
    def _mono(self) -> int:
        """本地离散时钟：每调用一次当作 '1 tick'；只用于本地冷却与TTL。"""
        # 也可以用自增计数器；这里复用 self.round 更直观
        return int(self.round)

    def _local_coalition_density(self) -> float:
        """仅基于“已知邻居标签缓存”计算：与我同 ci 的邻居占比。"""
        outs = getattr(self, "outs", None) or []
        if not outs:
            return 0.0
        same = 0
        my_ci = self.coalition_index
        for n in outs:
            meta = self._neighbor_coal_cache.get(n)
            if meta and meta[0] == my_ci:
                same += 1
        return same / float(len(outs))

    def _tau_join(self, dens_i: float) -> float:
        """自适应换盟阈值：联盟越拥挤，越容易离开（τ 变小）。"""
        # τ = max(0, τ0 - β * max(0, dens_i - target))
        return max(0.0, self._tau0 - self._beta * max(0.0, dens_i - self._target_density))

    def _drain_coalition_deltas(self, k: int = 3):
        """
        每次发送前取出至多 k 条“未过期”的 (member, ci, ver) 做 piggyback。
        只做本地节流：基于离散 tick 控制出队频率；不过期直接带走。
        """
        out, tmp = [], []
        tick = self._mono()
        if tick - self._last_broadcast_tick < self._broadcast_min_interval_tick:
            return out
        self._last_broadcast_tick = tick

        while self._coal_delta_q and len(out) < k:
            member, ci, ver, ts = self._coal_delta_q.popleft()
            out.append((int(member), int(ci), int(ver)))
        # 无需放回 tmp（简单起见），deltas 会持续新鲜产生
        return out
    
    def add_self_coalition_info(self, message: Message):
        message.add_params(MyMessage.MSG_ARG_KEY_COALITION_ID, self.coalition_index)
        message.add_params(MyMessage.MSG_ARG_KEY_COALITION_VERSION, self.coalition_ver)

    def add_coalition_deltas(self, message: Message):
        """发送消息前调用，附加 piggyback 的 (member, ci, ver) 列表。"""
        deltas = self._drain_coalition_deltas(k=3)
        if deltas:
            message.add_params(MyMessage.MSG_ARG_KEY_DELTAS, deltas)


    def coalition_join_and_send_notification(self, inviter_id: int, inviter_ci: int, inviter_ver: int):
        """
        覆盖式换盟（不广播）：
        - ver = max(self.ver, inviter_ver) + 1
        - 回执 inviter 一个 ACK（轻量），并把 (self, ci, ver) 放进懒传播队列
        """
        with self._coal_lock:
            new_ci  = int(inviter_ci)
            new_ver = max(int(self.coalition_ver), int(inviter_ver)) + 1

            # 覆盖式切换自己的标签
            self.coalition_index = new_ci
            self.coalition_ver   = new_ver

            # 生成自己的增量，供后续 piggyback
            key = (self.worker_index, new_ver)
            if key not in self._coal_seen_delta:
                self._coal_seen_delta.add(key)
                self._coal_delta_q.append((self.worker_index, new_ci, new_ver, self._mono()))

            # 仅通知邀请者（沿用现有的邻居消息类型）
            coalition_join_notification = Message(MyMessage.MSG_TYPE_COALITION_JOIN_NOTIFICATION, self.get_sender_id(), inviter_id)
            coalition_join_notification.add_params(MyMessage.MSG_ARG_KEY_COALITION_ID, new_ci)
            coalition_join_notification.add_params(MyMessage.MSG_ARG_KEY_COALITION_VERSION, new_ver) 
            try:
                self.send_message(coalition_join_notification)
            except Exception:
                logging.exception("send coalition join notification failed")

    def handle_coalition_join(self, msg_params, sender_id):
        try:
            # 1) 记录对方的 (ci, ver)（若有）
            ci_ver = msg_params.get(MyMessage.MSG_TYPE_COAL_INFO) or {}
            ci = int(ci_ver.get(MyMessage.MSG_ARG_KEY_COALITION_ID, -1))
            ver = int(ci_ver.get(MyMessage.MSG_ARG_KEY_COALITION_VERSION, -1))
            if ci >= 0 and ver >= 0:
                with self._coal_lock:
                    # 去重：见过同一个 (member, ver) 就不再处理
                    key = (sender_id, ver)
                    if key in self._coal_seen_delta:
                        return
                    self._coal_seen_delta.add(key)

                    # 只要 ver 变大，就覆盖邻居缓存（我们无需维护全量 coalition_set）
                    old = self._neighbor_coal_cache.get(sender_id)
                    if (old is None) or (ver > old[1]):
                        self._neighbor_coal_cache[sender_id] = (ci, ver, self._mono())

                    # 将该增量再入队，等待后续 piggyback（形成懒传播）
                    self._coal_delta_q.append((sender_id, ci, ver, self._mono()))

        except Exception:
            logging.exception("handle_coalition_join handling failed")

    def coalition_info_and_pigiback_update(self, msg_params, sender_id):
        # ---------- 先处理 coalition piggyback ----------
        # 1) 记录对方的 (ci, ver)（若有）
        # 2) 判断是否触发“换盟”？ 判断发生在计算sim之后。因此由update_utility的回调触发 switch_coalition
        # 3) 处理 piggyback 的其他 deltas（形成懒传播链）
        # -----------------------------------------------
        try:
            # 1) 记录对方的 (ci, ver)（若有）
            ci_ver = msg_params.get(MyMessage.MSG_TYPE_COAL_INFO) or {}
            ci = int(ci_ver.get(MyMessage.MSG_ARG_KEY_COALITION_ID, -1))
            ver = int(ci_ver.get(MyMessage.MSG_ARG_KEY_COALITION_VERSION, -1))
            deltas = ci_ver.get(MyMessage.MSG_ARG_KEY_DELTAS, None)
            if ci >= 0 and ver >= 0:
                with self._coal_lock:
                   # 去重：见过同一个 (member, ver) 就不再处理
                    key = (sender_id, ver)
                    if key in self._coal_seen_delta:
                        return
                    self._coal_seen_delta.add(key)

                    # 只要 ver 变大，就覆盖邻居缓存（我们无需维护全量 coalition_set）
                    old = self._neighbor_coal_cache.get(sender_id)
                    if (old is None) or (ver > old[1]):
                        self._neighbor_coal_cache[sender_id] = (ci, ver, self._mono())

                    # 将该增量再入队，等待后续 piggyback（形成懒传播）
                    self._coal_delta_q.append((sender_id, ci, ver, self._mono()))
                    
                    if deltas:
                        for tup in deltas:
                            try:
                                member, ci, ver = int(tup[0]), int(tup[1]), int(tup[2])
                            except Exception:
                                continue
                            with self._coal_lock:
                                key = (member, ver)
                                if key in self._coal_seen_delta:
                                    continue
                                self._coal_seen_delta.add(key)

                                old = self._neighbor_coal_cache.get(member)
                                if (old is None) or (ver > old[1]):
                                    self._neighbor_coal_cache[member] = (ci, ver, self._mono())
                                # 继续懒传播
                                self._coal_delta_q.append((member, ci, ver, self._mono()))
        except Exception:
            logging.exception("coalition_info_and_pigiback_update handling failed")

    
    def switch_coalition(self, sender_id):
        #  判断是否触发“换盟”？
        #  近似 gain = util[sender] - 平均(我方同盟邻居 util)
        try:
            util_sender = float(self.util_cache[sender_id])
        except Exception:
            util_sender = 0.0
        outs = self.outs or []
        my_ci = self.coalition_index
        in_coal = [n for n in outs
                    if (self._neighbor_coal_cache.get(n) and
                        self._neighbor_coal_cache[n][0] == my_ci)]
        if in_coal:
            u_curr = float(np.mean([self.util_cache[n] for n in in_coal]))
        else:
            u_curr = 0.0
        gain = util_sender - u_curr
        dens_i = self._local_coalition_density()
        if gain > self._tau_join(dens_i) and ci != my_ci:
            # 只回执邀请者，不广播
            self.coalition_join_and_send_notification(sender_id, ci, ver)

            # # 3) 处理 piggyback 的其他 deltas（形成懒传播链）
            # deltas = msg_params.get("coal_deltas", None)
            # if deltas:
            #     self.handle_msg_coalition_join({"coal_deltas": deltas})

            # # 4) 有可能这是一个 ACK（比如 inviter 回来一条）
            # if msg_params.get("msg_type") == "COALITION_JOIN_ACK":
            #     self.handle_msg_coalition_join(msg_params)


    # ------------------------------------------------------------------
    # Hedonic utility 更新
    # ------------------------------------------------------------------
    def _update_neighbor_utility(self, nbr: int, cos_sim: float, staleness: int, round, epoch, num_iterations):
        self.round = round
        self.epochs = epoch
        self.num_iterations = num_iterations
        # update_time = time.time()
        """更新 util_cache，然后自调 util_threshold，使 good_set 占比≈30%。"""
        # 1. 计算当前邻居效用并做 EMA
        bw   = self.bw_norm[nbr]

        phase1_round = self.epochs * self.num_iterations * self.PHASE1
        if self.round < phase1_round:
            t    = self.round 
            lam_bw  = self.lambda_bw0
            lam_sim = 0
        else:
            t_adj    = self.round - phase1_round
            lam_bw  = max(self.lambda_bw0 * np.exp(- t_adj / self.time_const), 0.01 * self.lambda_bw0)  # 防止过小
            lam_sim = self.lambda_sim0 * (1 - np.exp(- t_adj / self.time_const))
            # lam_bw = 0.5
            # lam_sim = 0.5
        util    = lam_bw * bw + lam_sim * cos_sim - self.lambda_dist * (1-staleness)
        self.util_cache[nbr] = (1 - self.util_alpha) * self.util_cache[nbr] + self.util_alpha * util

        # 2. 依据当前阈值划分 good / bad
        if self.util_cache[nbr] >= self.util_threshold:
            self.good_set.add(nbr); self.bad_set.discard(nbr)
        else:
            self.bad_set.add(nbr);  self.good_set.discard(nbr)

        # 3. 动态调整阈值：目标 good_ratio≈0.30 ±0.05
        outs = self.outs  # 固定拓扑列表
        if outs:
            good_ratio = len(self.good_set.intersection(outs)) / len(outs)
            if good_ratio < self.target_good_ratio - self.tolerance_ratio:
                self.util_threshold -= self.adjust_step   # good 太少 → 降低阈值
            elif good_ratio > self.target_good_ratio + self.tolerance_ratio:
                self.util_threshold += self.adjust_step   # good 太多 → 提高阈值

            # 4. 若阈值改变，需要重新划分 outs 中的成员
            for n in outs:
                if self.util_cache[n] >= self.util_threshold:
                    self.good_set.add(n); self.bad_set.discard(n)
                else:
                    self.bad_set.add(n);  self.good_set.discard(n)
        # update_time = time.time() - update_time
        # logging.info("update_neighbor_utility time %.4f" % update_time)


    def _choose_neighbor(self):                # HEDONIC★ 三阶段 + 单 send + 时间窗
        """选择一个邻居进行发送。
        · 阶段①(前 15%)  : 纯均匀随机  —— 充分探索 / 快速扩散
        · 阶段②(15%~70%): 偏好 good_idx —— Soft‑max + ε/|bad|
        · 阶段③(>=70%)  : 只在 good_idx Soft‑max，ε→0
        同时始终保证  time_window  内每个 outs 至少被选一次。"""
        outs  = self.outs
        cur_r = self.round

        # 0️⃣  强连通保障：优先处理过期邻居（在 outs 中）
        overdue = [n for n in outs if cur_r - self.last_chosen_round[n] >= self.time_window]
        if overdue:
            choice = np.random.choice(overdue)
            self.last_chosen_round[choice] = cur_r

            # if self.worker_index == 5:
            #     logging.debug(f"[Round {self.round}] Overdue....Worker 5 chose neighbor {choice} ")
            return int(choice)

        # 1️⃣ 计算训练进度比例 progress ∈ (0,1)
        total_rounds = self.epochs * self.num_iterations + 1e-8
        progress = cur_r / total_rounds

        PHASE1 = self.PHASE1   # <15% : 全随机
        PHASE3 = self.PHASE3   # >70% : 只 good

        # (A) 前期：带宽主导探索
        if progress < PHASE1:
            # if self.worker_index == 5:
            #     logging.info(f"[Round {self.round}] Worker {self.worker_index} in Phase 1, self.util_cache: {self.util_cache[self.good_set]}")
            logits = self.bw_norm[outs]             # 已 0-1 归一化
            probs  = np.exp(logits - logits.max())
            probs  = probs / probs.sum()
            choice = np.random.choice(outs, p=probs)
            self.last_chosen_round[choice] = cur_r
            return int(choice)
            # choice = np.random.choice(outs)
            # self.last_chosen_round[choice] = cur_r
            # # if self.worker_index == 5:
            # #     logging.debug(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
            # return int(choice)


        # choice = np.random.choice(outs)
        # self.last_chosen_round[choice] = cur_r
        # return int(choice)


        # 构造 good / bad 列表（均在 outs 内）
        good_idx = [n for n in outs if n in self.good_set]
        bad_idx  = [n for n in outs if n in self.bad_set]

        # (B) 后期：good_only & ε → 0
        if progress >= PHASE3 and good_idx:
            eps     = 0.05
            # logits = self.util_cache[good_idx] - np.max(self.util_cache[good_idx])
            # probs  = np.exp(logits); probs = probs / probs.sum()
            # choice = np.random.choice(good_idx, p=probs)
            # self.last_chosen_round[choice] = cur_r
            # # if self.worker_index == 5:
            # #     logging.info(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
            # return int(choice)

        # if self.round == self.epochs * self.num_iterations * self.PHASE1:
        #     if self.worker_index == 5:
        #         logging.info(f"[Round {self.round}] Worker {self.worker_index} in Phase 2, self.util_cache: {self.util_cache[good_idx]}")
        # (C) 中期：Soft‑max good + ε 均匀 bad
        eps     = self.util_eps                       # 典型 0.02
        prob_g, prob_b = np.array([]), np.array([])

        if good_idx:
            logits = self.util_cache[good_idx]
            logits = logits - logits.max()
            w_g    = np.exp(logits)
            prob_g = (1 - eps) * w_g / w_g.sum()
        if bad_idx:
            prob_b = np.ones(len(bad_idx)) * (eps / len(bad_idx))

        all_probs = np.concatenate([prob_g, prob_b]); all_idxs = good_idx + bad_idx
        all_probs = all_probs / all_probs.sum()
        choice    = np.random.choice(all_idxs, p=all_probs)
        self.last_chosen_round[choice] = cur_r
        # if self.worker_index == 5:
        #     logging.info(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
        return int(choice)
