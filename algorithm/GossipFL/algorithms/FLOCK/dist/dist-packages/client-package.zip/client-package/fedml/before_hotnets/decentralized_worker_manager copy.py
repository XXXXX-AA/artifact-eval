import logging
import threading
import time
from copy import deepcopy

import traceback
from mpi4py import MPI
import numpy as np

from fedml_core.distributed.client.client_manager import ClientManager
from fedml_core.distributed.communication.message import Message

from algorithms.baseDecent.decentralized_worker_manager import BaseDecentralizedWorkerManager

from utils.context import (
    raise_MPI_error,
    raise_error_without_process,
    get_lock,
)
from utils.timer import Timer
from utils.tracker import RuntimeTracker
# from fedml_api.utils.timer_with_cuda import Timer
from utils.metrics import Metrics
from utils.wandb_util import wandb_log
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from .compressor import SAPS_FLCompressor
from .utils import generate_bandwidth

from .SAPS_topology_manager import SAPSTopologyManager
from .message_define import MyMessage



comm = MPI.COMM_WORLD

class DecentralizedWorkerManager(BaseDecentralizedWorkerManager):
    def __init__(self, args, comm, rank, size, worker, topology_manager, model_trainer, timer, metrics):
        super().__init__(args, comm, rank, size, worker, topology_manager, model_trainer, timer, metrics)
        # self.topology_manager.generate_topology(t=self.global_round_idx)
        # self.training_thread = threading.Thread(name='training', target=self.run_async)
        # self.training_thread.start()
        self.neighbor_transfer_lock = threading.Lock()
        self.sync_receive_all_event = threading.Event()
        self.complete_aggregation_event = threading.Event()

        # the reward function self.prev_loss = self.loss-loss - 1/bandwidth
        self.prev_loss = False
        self.neighbor_loss_flag = {}  # { neighbor_id: bool, … }
        self.loss = float('inf')  # Current loss
        self.cluster_name = f"cluster_{self.worker_index}"  # Cluster name
        self.cluster_neighbors = [0] * args.client_num_in_total  # Cluster neighbors array
        self.cluster_neighbors[self.worker_index] = 1  # Initialize self as a neighbor
        self.last_layer_params = None  # Last layer parameters
        self.neighbor_last_layer_params = None  # Neighbor's last layer parameters

        # For game theory ---------------------------------------------------------
        self.bandwidth_parameter=0.02 # bw (0,5]  self.bandwidth_parameter * bw (0,0.1]
        self.model_similarity_paramter=0.1 # model_similarity_paramter * cosine_sim (0,0.1]
        self.threshold=0  #increasing--------for decreasing speed of 
        self.max_cluster_ratio=0.25 # if > max_cluster_ratio, increase bandwidth_parameter, and decrease model_similarity_parameter
        self.min_cluster_ratio=0.1 # if < min_cluster_ratio, decrease bandwidth_parameter, and increase model_similarity_parameter


        # compression part
        self.compression = args.compression
        assert self.compression in ["topk", "randomk", "quantize", "sign"]
        self.compressor = SAPS_FLCompressor(comm_op=self.compression,
                                        compress_ratio=args.compress_ratio,
                                        quantize_level=args.quantize_level,
                                        is_biased=(args.is_biased == 1),)
        
        


    def run(self):
        # self.start_training()
        self.training_thread.start()
        logging.debug("Wait for the barrier!")
        comm.Barrier()
        time.sleep(1)
        logging.debug("MPI exit barrier!")

        if self.worker_index == 0:
            logging.debug("COORDINATOR notify clients to start!")
            self.coodinator_thread.start()
            self.notify_clients()
        super().run()


    def register_message_receive_handlers(self):
        # 注册接收 Cluster Info
        self.register_message_receive_handler(MyMessage.MSG_TYPE_CLUSTER_INFO,
                                              self.handle_msg_cluster_info)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR,
                                              self.handle_msg_from_neighbor)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_CLIENT_TO_COORDINATOR,
                                              self.handle_msg_client_to_coordinator)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_COORDINATOR_TO_CLIENT,
                                              self.handle_msg_coordinator_to_client)



    # def start_training(self):
    #     self.global_round_idx = 0
    #     self.__train()


    def handle_msg_cluster_info(self, msg_params):
        sender        = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        # flag          = msg_params.get(MyMessage.MSG_ARG_KEY_LOSS_DECREASED, False)
        # nbr_name      = msg_params.get(MyMessage.MSG_ARG_KEY_CLUSTER_NAME, None)
        # nbr_neighbors = msg_params.get(MyMessage.MSG_ARG_KEY_CLUSTER_NEIGHBORS, [])

        flag = msg_params.get(MyMessage.MSG_ARG_KEY_LOSS_DECREASED)
        if flag is None:
            flag = False

        nbr_name = msg_params.get(MyMessage.MSG_ARG_KEY_CLUSTER_NAME)
        nbr_neighbors = msg_params.get(MyMessage.MSG_ARG_KEY_CLUSTER_NEIGHBORS)
        # nbr_last_layer_params = msg_params.get(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS)
        # 假设这两个变量都是一维 numpy 数组
        # cosine_sim = np.dot(nbr_last_layer_params, self.last_layer_params) / (
        #     np.linalg.norm(nbr_last_layer_params) * np.linalg.norm(self.last_layer_params) + 1e-8
        # )
        # if cosine_sim > 0.8:
        # logging.info("worker %d 与 neighbor %d 的最后一层参数很相似，余弦相似度为: %.4f" % ( self.worker_index, sender, cosine_sim))
        # 更新 neighbor_loss_flag
        self.neighbor_loss_flag[sender] = flag

        # 只有当双方都 loss↓ 时，才做合并
        # 只有当双方都 loss↓ 时，才考虑合并
        if self.prev_loss and flag:
            # case1: 同一个簇，只需并集合并 neighbors
            if nbr_name == self.cluster_name:
                # if (!(nbr_neighbors==self.cluster_neighbors)):
                for i, v in enumerate(nbr_neighbors):
                    if v == 1:
                        self.cluster_neighbors[i] = 1

            else:
                # if self.prev_loss and flag:
                local_id = int(self.cluster_name.split("_",1)[1])
                other_id = int(nbr_name.split("_",1)[1]) if nbr_name else float('inf')
                if local_id <= other_id:
                    self.cluster_neighbors[sender] = 1
                    logging.info("worker %d merging worker %d to  cluster_name: %s, cluster_neighbors: %s" % (
                        self.worker_index, sender, self.cluster_name, self.cluster_neighbors)) 
                else:
                    self.cluster_name      = nbr_name
                    self.cluster_neighbors = nbr_neighbors.copy()
                    self.cluster_neighbors[self.worker_index] = 1
                    logging.info("worker %d changing cluster to , cluster_name: %s, cluster_neighbors: %s" % (
                        self.worker_index, self.cluster_name, self.cluster_neighbors))  
                # if sum(self.cluster_neighbors) < self.min_cluster_ratio * self.args.client_num_in_total:
                #     # 如果簇的大小小于最小比例，则增加带宽参数，减少模型相似度参数
                #     self.bandwidth_parameter =self.bandwidth_parameter ** 2
                #     self.model_similarity_paramter *= 1.1
                #     logging.info("worker %d decreasing bandwidth_parameter: %f, increasing model_similarity_paramter: %f" % (
                #         self.worker_index, self.bandwidth_parameter, self.model_similarity_paramter))
                # elif sum(self.cluster_neighbors) > self.max_cluster_ratio * self.args.client_num_in_total:
                #     # 如果簇的大小大于最大比例，则减少带宽参数，增加模型相似度参数
                #     self.bandwidth_parameter = self.bandwidth_parameter ** 0.5
                #     self.model_similarity_paramter *= 0.9
                #     logging.info("worker %d increasing bandwidth_parameter: %f, decreasing model_similarity_paramter: %f" % (
                #         self.worker_index, self.bandwidth_parameter, self.model_similarity_paramter))



    def handle_msg_from_neighbor(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        self.neighbor_last_layer_params = msg_params.get(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS)

        # training_interation_result = msg_params.get(MyMessage.MSG_ARG_KEY_PARAMS_1)
        # local_sample_number = msg_params.get(MyMessage.MSG_ARG_KEY_NUM_SAMPLES)

        # =========================== wait for complete aggregation
        logging.debug("receive rank %d message, wait for complete aggregation" %
            (sender_id))

        with get_lock(self.neighbor_transfer_lock):
            logging.debug("handle_msg_from_neighbor. sender_id = " + str(sender_id))
            # self.worker.add_result(sender_id, training_interation_result)
            self.worker.add_result(sender_id, msg_params)

        if self.worker.check_whether_all_receive():
            logging.debug(">>>>>>>>>>>>>>>WORKER %d, ROUND %d finished!<<<<<<<<" % (self.worker_index, self.global_round_idx))
            self.global_round_idx += 1

            self.sync_receive_all_event.set()
            if self.global_round_idx == self.comm_round:
                self.finish()
            # self.__train()


    def handle_msg_from_neighbor_old(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        # training_interation_result = msg_params.get(MyMessage.MSG_ARG_KEY_PARAMS_1)
        # local_sample_number = msg_params.get(MyMessage.MSG_ARG_KEY_NUM_SAMPLES)

        # =========================== wait for complete aggregation
        logging.debug("receive rank %d message, wait for complete aggregation" %
            (sender_id))
        self.complete_aggregation_event.wait()
        self.neighbor_transfer_lock.acquire()

        logging.debug("handle_msg_from_neighbor. sender_id = " + str(sender_id))
        # Not used to add compressed result into cache
        # self.worker.add_result(sender_id, training_interation_result)

        logging.debug("receive rank %d message, msg_params.get(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1): %s" % (
             sender_id, msg_params.get(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1)[0:10] )
        )

        self.worker.flag_neighbor_result_received_dict[sender_id] = True
        assert self.worker.shapes is not None
        self.compressor.original_shapes = self.worker.shapes
        if self.args.Failure_chance is not None and np.random.rand(1) < self.args.Failure_chance:
            logging.info("Communication Failure happens on worker: {}, Failure_chance: {}".format(
                self.worker_index, self.args.Failure_chance))
        else:
            self.compressor.uncompress(msg_params, self.gossip_info[sender_id],
                self.worker.neighbor_hat_params["memory"], 
                self.selected_shapes, self.worker.shapes,
                self.worker.device
            )

        if self.neighbor_transfer_lock.locked():
            self.neighbor_transfer_lock.release()
        if self.worker.check_whether_all_receive():
            logging.debug(">>>>>>>>>>>>>>>WORKER %d, ROUND %d finished!<<<<<<<<" % (self.worker_index, self.global_round_idx))
            self.global_round_idx += 1

            self.sync_receive_all_event.set()
            if self.global_round_idx == self.comm_round:
                self.finish()
            # self.__train()


    def run_sync(self):
        with raise_MPI_error():
            # for the first iteration usage
            self.topology_manager.generate_topology(t=self.global_round_idx)
            self.worker.refresh_gossip_info()
            self.refresh_gossip_info()
            # reset the neighbor_hat_params for storing new values
            self.worker.init_neighbor_hat_params()
            for epoch in range(self.epochs):
                self.epoch = epoch

                # update worker's dataset and data loaderw
                with raise_error_without_process():
                    self.worker.train_local.sampler.set_epoch(epoch)
                # self.worker.update_dataset()
                self.epoch_init()
                if self.epoch%5 == 0:
                    logging.info("The cluster info of client: {}, in Cluster: {}, with neighbors{}".format(
                            self.worker_index, self.cluster_name, self.cluster_neighbors))

                for iteration in range(self.worker.num_iterations):
                    self.iteration = iteration

                    self.prev_loss = False
                    self.neighbor_loss_flag.clear()

                    logging.debug("wait start_epoch_event")

                    self.start_epoch_event.wait()
                    logging.debug("Begin iteration")

                    # Get model params
                    params, _ = get_data(
                        self.worker.param_groups, self.worker.param_names, is_get_grad=False
                    )
                    last_layer_param = params[-2]           # 最后一层参数（Tensor）
                    last_layer_vector = last_layer_param.view(-1)  # 展平成一维向量
                    self.last_layer_params = last_layer_vector.detach().cpu().numpy()  # 转换为 NumPy 数组

                    
                    
                    flatten_params = TensorBuffer(params)

                    # compress
                    sync_buffer = {
                        "original_shapes": self.worker.shapes,
                        "flatten_params": flatten_params,
                    }
                    self.compressor.compress(sync_buffer)
                    self.selected_shapes = sync_buffer["selected_shapes"]

                    # allow receive others' models at the beginning for acceleration
                    # Must after the selected_shapes 
                    # self.complete_aggregation_event.set()

                    # begin to send model
                    logging.debug("Begin send and receive")
                    logging.debug(self.topology_manager.topology)
                    for neighbor_idx in self.topology_manager.get_out_neighbor_idx_list(self.worker_index):
                        if self.compression in ["randomk", "topk"]:
                            self.send_sparse_params_to_neighbors(neighbor_idx, 
                                sync_buffer["flatten_selected_values"].buffer.cpu(),
                                sync_buffer["flatten_selected_indices"].buffer.cpu(),
                                self.worker.get_dataset_len())
                        # Not support Now
                        elif self.compression == "quantize":
                            raise NotImplementedError
                        # Not support Now
                        elif self.compression == "sign":
                            raise NotImplementedError
                        else:
                            raise NotImplementedError
                    # wait for receiving all
                    self.sync_receive_all_event.wait()
                    self.worker.aggregate(self.compressor, self.selected_shapes, self.gossip_info)

                    # ready for aggregation in next epoch
                    # self.complete_aggregation_event.clear()

                    # Get weighted hat params and apply the local gradient.
                    self.neighbor_transfer_lock.acquire()


                    # add the sparsed part
                    self.compressor.uncompress_direct(
                        sync_buffer, self.worker.neighbor_hat_params["memory"],
                        self.selected_shapes, self.worker.shapes)
                    sync_buffer["flatten_params"].unpack(params)

                    if self.neighbor_transfer_lock.locked():
                        self.neighbor_transfer_lock.release()

                    if self.args.Failure_chance is not None and np.random.rand(1) < self.args.Failure_chance:
                        logging.info("Communication Failure happens on worker: {}, Failure_chance: {}".format(
                            self.worker_index, self.args.Failure_chance))
                    else:
                        self.lr_schedule(self.epoch, self.iteration, self.global_round_idx,
                                        self.worker.num_iterations, self.args.warmup_epochs)
                        # update x_half to x_{t+1} by SGD
                        loss, output, target \
                            = self.worker.train_one_step(self.epoch, self.iteration,
                                                            self.train_tracker, self.metrics)
                        # if loss < self.worker.loss:
                        #     self.prev_loss = True

                        # decreased = False
                        # if hasattr(self.worker, "loss") and self.worker.loss is not None:
                        #     decreased = (loss < self.worker.loss)
                        # 更新标记和 worker.loss
                        self.prev_loss        = (loss < self.loss)
                        loss_change = self.loss-loss
                        # logging.info("worker {} loss: {}, prev_loss: {}, loss_change: {}".format(
                        #     self.worker_index, loss, self.prev_loss, loss_change))
                        # self.prev_loss        = (loss - self.loss - self.topology_manager.bandwidth[self.worker_index][])
                        self.loss      = float(loss)

                        for nbr in self.topology_manager.get_out_neighbor_idx_list(self.worker_index):
                            bw = self.topology_manager.bandwidth[self.worker_index][nbr]
                            if self.neighbor_last_layer_params is not None and self.last_layer_params is not None:
                                # 计算余弦相似度
                                cosine_sim = np.dot(self.neighbor_last_layer_params, self.last_layer_params) / (np.linalg.norm(self.neighbor_last_layer_params) * np.linalg.norm(self.last_layer_params) + 1e-8)
                                # logging.info("worker {} 与 neighbor {} 的最后一层参数很相似，余弦相似度为: {:.4f}".format(self.worker_index, nbr, cosine_sim))
                            else:
                                cosine_sim = 0.0
                            loss_change = loss_change + self.bandwidth_parameter*bw + self.model_similarity_paramter * cosine_sim

                            threshold = 0.20
                            epsilon = 1e-8
                            self.prev_loss = (loss_change - threshold) > -epsilon
                            # 0.14 is a threshold, self.model_similarity_paramter * cosine_sim>0.09, self.bandwidth_parameter*bw> 0.02 * 3.5 = 0.07
                            if self.prev_loss:
                                logging.info("self.prev_loss = (loss_change > 0): bw {}, self.bandwidth_parameter*bw: {}, self.model_similarity_paramter * cosine_sim: {},loss_change: {}, self.prev_loss: {}".format(bw, self.bandwidth_parameter*bw, self.model_similarity_paramter* cosine_sim, loss_change, self.prev_loss))
                                msg = Message(MyMessage.MSG_TYPE_CLUSTER_INFO,self.get_sender_id(), nbr)
                                msg.add_params(MyMessage.MSG_ARG_KEY_LOSS_DECREASED,self.prev_loss)
                                msg.add_params(MyMessage.MSG_ARG_KEY_CLUSTER_NAME,self.cluster_name)
                                msg.add_params(MyMessage.MSG_ARG_KEY_CLUSTER_NEIGHBORS,self.cluster_neighbors)
                                msg.add_params(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS,self.cluster_neighbors)
                                msg.add_params(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS, self.last_layer_params)
                                self.send_message(msg)

                    # batch_metric_stat = self.metrics.evaluate(loss, output, target)
                    # self.train_tracker.update_metrics(batch_metric_stat, n_samples=target.size(0))
                    # logging.info('Local Training Epoch: {} iter: {} \t Loss: {:.6f}, Acc1: {:.6f}'.format(
                    #                 epoch, iteration, batch_metric_stat['Loss'], batch_metric_stat['Acc1']))
                    # logging.info('(Local Training Epoch: {}, Iter: {} '.format(
                    #     epoch, iteration) + self.metrics.str_fn(batch_metric_stat))
                    self.start_epoch_event.clear()
                    self.sync_receive_all_event.clear()

                    """
                        Before send msg to coordinator,
                        generate topology firstly.
                    """
                    self.topology_manager.generate_topology(t=self.global_round_idx)
                    self.worker.refresh_gossip_info()
                    self.refresh_gossip_info()
                    # reset the neighbor_hat_params for storing new values
                    self.worker.init_neighbor_hat_params()

                    self.test_and_send_to_coordinator(iteration, epoch)
                    # self.prev_loss = False
                # self.model_trainer.lr_schedule(epoch+1)



    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]


    def send_result_to_neighbors(self, receive_id, client_params1, local_sample_number):
        logging.debug("send_result_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_PARAMS_1, client_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)

    def send_sparse_params_to_neighbors(self, receive_id, client_sparse_params1, client_sparse_index1, local_sample_number):
        logging.debug("send_sparse_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_SPARSE_PARAMS_1, client_sparse_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1, client_sparse_index1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        # Add last layer params to the message
        message.add_params(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS, self.last_layer_params)
        self.send_message(message)

    def send_quant_params_to_neighbors(self, receive_id, client_quant_params1, local_sample_number):
        logging.debug("send_quant_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_QUANT_PARAMS_1, client_quant_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)

    def send_sign_params_to_neighbors(self, receive_id, client_sign_params1, local_sample_number):
        logging.debug("send_sign_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_SIGN_PARAMS_1, client_sign_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)




