import logging
import threading
import time
from copy import deepcopy
import torch

import traceback
from mpi4py import MPI
import numpy as np

from fedml_core.distributed.client.client_manager import ClientManager
from fedml_core.distributed.communication.message import Message

from algorithms.baseDecent.decentralized_worker_manager import BaseDecentralizedWorkerManager

from utils.context import (
    raise_MPI_error,
    raise_error_without_process,
    get_lock,
)
from utils.timer import Timer
from utils.tracker import RuntimeTracker
# from fedml_api.utils.timer_with_cuda import Timer
from utils.metrics import Metrics
from utils.wandb_util import wandb_log
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from .compressor import SAPS_FLCompressor
from .utils import generate_bandwidth

from .SAPS_topology_manager import SAPSTopologyManager
from .message_define import MyMessage



comm = MPI.COMM_WORLD

class DecentralizedWorkerManager(BaseDecentralizedWorkerManager):
    def __init__(self, args, comm, rank, size, worker, topology_manager, model_trainer, timer, metrics):
        super().__init__(args, comm, rank, size, worker, topology_manager, model_trainer, timer, metrics)
        # self.topology_manager.generate_topology(t=self.global_round_idx)
        # self.training_thread = threading.Thread(name='training', target=self.run_async)
        # self.training_thread.start()
        self.neighbor_transfer_lock = threading.Lock()
        self.sync_receive_all_event = threading.Event()
        self.complete_aggregation_event = threading.Event()

        # whether all workers finised
        self.ifStop = False
        self.round = 0  # Current round index

        # # ---------- Error-Feedback 变量 ----------
        # self.residual     = None   # r_i，存放未发送的差分
        # self.prev_params  = None   # θ_prev，用来计算本轮真实差分
        # self.buffer1 = None  # 用于存储本轮的 flatten_params
        # self.buffer2 = None  # 用于存储上轮的 flatten_params

        # ---------- Push‑Sum & EF 变量 ----------
        self.residual= None   # 误差缓冲 r
        self.sent_part= None   # 复用 scratch：保存已发送部分
        self.to_store_agg = None  # 用于存储聚合的邻居参数

        # ---- HEDONIC 参数 ----
        self.bandwidth      = generate_bandwidth(args)      # 0‑1 归一化带宽矩阵
        # 2) 对本节点这一行做 log1p 局部归一化，保存在 bw_norm_row
        bw_raw      = self.bandwidth[self.worker_index]      # 1-D
        bw_log_max  = np.log1p(bw_raw).max() or 1.0             # 防除 0
        self.bw_norm = np.log1p(bw_raw) / bw_log_max        # 0-1
        self.outs = self.my_get_out_neighbor_idx_list(self.worker_index)
        self.util_cache     = np.zeros(size)                # 邻居效用 EMA
        self.util_alpha     = 0.2                           # EMA 衰减 0.1
        self.util_eps       = 0.3                          # ε‑greedy 0.05(630-4)  0.1(0701-1)
        self.lambda_bw0     = 3.0                           # 1 3
        self.lambda_sim0    = 0.8                           # 0.2.  0.8 2
        # self.lambda_loss    = 0.2
        self.lambda_dist    = 0.05
        self.time_const     = 1.0 * self.epochs                           # 退火常数 200 0.5 0.7
        # -------- 阈值 + 时间窗 -------- HEDONIC★
        self.util_threshold = 0.0                      # 初始阈值
        self.target_good_ratio = 0.3                   # 期望 good_set ≈ 30% of outs
        self.tolerance_ratio   = 0.05                  # 可接受波动 ±5%
        self.adjust_step       = 0.002                 # 每次阈值调整幅度 0.07
        # self.time_window    = getattr(args, "time_window", 2*size)   # 至少每 50 轮被选一次 2/3 * size
        self.time_window = int(np.ceil(3 * np.log(size)))
        self.last_chosen_round = np.zeros(size, dtype=int)         # 记录上次被选轮次

        # -------- 缓存高/低分邻居集合 -------- HEDONIC★
        self.good_set = set()   # util >= threshold
        self.bad_set  = set(range(size))         # 记录上次被选轮次

        self.PHASE1 = 0.04   # <15% : 全随机
        self.PHASE3 = 0.6   # >70% : 只
        # 固定拓扑：一次性生成并缓存 outs
        
        # self.topology_manager.generate_topology(t=0)
        # self.outs = self.topology_manager.get_out_neighbor_idx_list(self.worker_index)
        # if self.worker_index == 5:
        #     logging.info(f"[Init] Worker 5 topology row: {self.bandwidth[self.worker_index]}")
        #     logging.info(f"[Init] Worker 5 outs: {self.outs}")

        # # self.worker.refresh_gossip_info()   
        # # self.refresh_gossip_info()    
        # if self.worker_index == 5:
        #     logging.info(f"[Init] Worker 5 topology row: {self.bandwidth[self.worker_index]}")
        #     logging.info(f"[Init] Worker 5 outs: {self.outs}")    
        # # the reward function self.prev_loss = self.loss-loss - 1/bandwidth
        # self.prev_loss = False
        # self.neighbor_loss_flag = {}  # { neighbor_id: bool, … }
        # self.loss = float('inf')  # Current loss
        # self.cluster_name = f"cluster_{self.worker_index}"  # Cluster name
        # self.cluster_neighbors = [0] * args.client_num_in_total  # Cluster neighbors array
        # self.cluster_neighbors[self.worker_index] = 1  # Initialize self as a neighbor
        # self.last_layer_params = None  # Last layer parameters
        # self.neighbor_last_layer_params = None  # Neighbor's last layer parameters

        # # For game theory ---------------------------------------------------------
        # self.bandwidth_parameter=0.02 # bw (0,5]  self.bandwidth_parameter * bw (0,0.1]
        # self.model_similarity_paramter=0.1 # model_similarity_paramter * cosine_sim (0,0.1]
        # self.threshold=0  #increasing--------for decreasing speed of 
        # self.max_cluster_ratio=0.25 # if > max_cluster_ratio, increase bandwidth_parameter, and decrease model_similarity_parameter
        # self.min_cluster_ratio=0.1 # if < min_cluster_ratio, decrease bandwidth_parameter, and increase model_similarity_parameter


        # compression part
        self.compression = args.compression
        assert self.compression in ["topk", "randomk", "quantize", "sign"]
        self.compressor = SAPS_FLCompressor(comm_op=self.compression,
                                        compress_ratio=args.compress_ratio,
                                        quantize_level=args.quantize_level,
                                        is_biased=(args.is_biased == 1),)
        # self._stop_event = threading.Event()
        # self._listen_thread = threading.Thread(
        #     target=self._listen_loop, daemon=True, name="mpi-listener"
        # )
        # self._listen_thread.start()
        
        


    def run(self):
        # self.start_training()
        self.training_thread.start()
        logging.debug("Wait for the barrier!")
        comm.Barrier()
        time.sleep(1)
        logging.debug("MPI exit barrier!")

        if self.worker_index == 0:
            logging.debug("COORDINATOR notify clients to start!")
            self.coodinator_thread.start()
            self.notify_clients()
        super().run()


    def register_message_receive_handlers(self):
        # # 注册接收 Cluster Info
        # self.register_message_receive_handler(MyMessage.MSG_TYPE_CLUSTER_INFO,
        #                                       self.handle_msg_cluster_info)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR,
                                              self.handle_msg_from_neighbor)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_CLIENT_TO_COORDINATOR,
                                              self.handle_msg_client_to_coordinator)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_COORDINATOR_TO_CLIENT,
                                              self.handle_msg_coordinator_to_client)



    # def start_training(self):
    #     self.global_round_idx = 0
    #     self.__train()

    # def _listen_loop(self):
    #     NEIGHBOR_TAG = MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR
    #     status = MPI.Status() 
    #     while not self._stop_event.is_set():
    #         if comm.Iprobe(source=MPI.ANY_SOURCE, tag=NEIGHBOR_TAG,
    #                    status=status):
    #             msg_params = comm.recv(source=status.Get_source(),
    #                                    tag=NEIGHBOR_TAG)
    #             self.handle_msg_from_neighbor(msg_params)
    #         else:
    #             time.sleep(0.001)


    def handle_msg_client_to_coordinator(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        logging.debug("handle_msg_client_to_coordinator.  Sender_id = " + str(sender_id)+" Finished training.")

        with get_lock(self.total_metric_lock):
            logging.debug("get metric lock, handle_msg_client_to_coordinator. sender_id = " + str(sender_id)+" Finished training.")
            self.flag_client_finish_dict[sender_id] = True
            self.check_worker_finish_and_notify()

    def handle_msg_coordinator_to_client(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        logging.debug("handle_msg_coordinator_to_client. Sender_id = " + str(sender_id)+" Finished training.")


    def handle_msg_from_neighbor(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        sender_round = msg_params.get(MyMessage.MSG_ARG_KEY_LOCAL_ROUND)
        # self.neighbor_last_layer_params = msg_params.get(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS)


        with get_lock(self.neighbor_transfer_lock):
            logging.debug("handle_msg_from_neighbor. sender_id = " + str(sender_id))
            self.worker.add_result_for_flock(sender_id, sender_round, msg_params)


    def run_sync(self):
        with raise_MPI_error():

            # reset the neighbor_hat_params for storing new values
            # self.worker.init_neighbor_hat_params()
            for epoch in range(self.epochs):
                self.epoch = epoch

                # update worker's dataset and data loaderw
                with raise_error_without_process():
                    self.worker.train_local.sampler.set_epoch(epoch)
                # self.worker.update_dataset()
                self.epoch_init()

                for iteration in range(self.worker.num_iterations):
                    self.iteration = iteration
                    # Train first, and then transfer the model
                    if self.args.Failure_chance is not None and np.random.rand(1) < self.args.Failure_chance:
                        logging.info("Communication Failure happens on worker: {}, Failure_chance: {}".format(
                            self.worker_index, self.args.Failure_chance))
                    else:
                        logging.debug("Start training on worker: {}, Epoch: {}, Iteration: {}".format(
                            self.worker_index, self.epoch, self.iteration))
                        self.lr_schedule(self.epoch, self.iteration, self.global_round_idx,
                                        self.worker.num_iterations, self.args.warmup_epochs)
                        # update x_half to x_{t+1} by SGD
                        loss, output, target \
                            = self.worker.train_one_step(self.epoch, self.iteration,
                                                            self.train_tracker, self.metrics)
                

                    params, self.worker.shapes = get_data(
                        self.worker.param_groups, self.worker.param_names, is_get_grad=False
                    )

                    
                    
                    flatten_params = TensorBuffer(params)

                    #(2) 初始化residual
                    # ---------- 2. 获取 flatten_params ----------
                    if self.residual is None:
                        self.residual = torch.zeros_like(flatten_params.buffer)  # r₀ = 0
                        self.sent_part = torch.zeros_like(flatten_params.buffer)  # scratch
                        self.to_store_agg = torch.zeros_like(flatten_params.buffer)  # 用于存储聚合的邻居参数


                    # compress
                    if self.worker_index == 5 and self.round <5:
                        logging.info(f"Before compress [Round {self.round}] Worker 5 params: {flatten_params.buffer[:10]}..residual{self.residual}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")
                    sync_buffer = {
                        "original_shapes": self.worker.shapes,
                        "flatten_params": flatten_params,
                    }
                    self.compressor.compress(sync_buffer)
                    self.selected_shapes = sync_buffer["selected_shapes"]

                    vals = sync_buffer["flatten_selected_values"].buffer
                    idxs = sync_buffer["flatten_selected_indices"].buffer

                    # ---------- 6. 更新 residual ----------
                    self.sent_part.zero_()  # 清空已发送部分
                    self.sent_part[idxs] = vals  # 已发送部分
                    self.residual=flatten_params.buffer - self.sent_part
                    if self.worker_index == 5 and self.round <5:
                        logging.info(f"Test range After compress [Round {self.round}] Worker 5 params: {flatten_params.buffer[idxs]}..residual{self.residual[idxs]}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part[idxs]}, len params{str(flatten_params.buffer.shape)},len idxs{str(idxs.shape)}.")
                    self.sent_part.div_(2)  # 发送部分除以2，用作push-sum求和累计
                    self.to_store_agg.zero_()  # 清空聚合缓存
                    if self.worker_index == 5 and self.round <5:
                        # logging.info(f"Test range After compress [Round {self.round}] Worker 5 params: {flatten_params.buffer[idxs]}..residual{self.residual[idxs]}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")
                        logging.info(f"After compress {self.round}] Worker 5 params: {flatten_params.buffer[:10]}..residual{self.residual}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")


                    # ------------------------------------------------------------------
                    # 发送阶段：按 Hedonic 选邻居
                    # ------------------------------------------------------------------
                    neighbor_idx = self._choose_neighbor()
                    if self.compression in ["randomk", "topk"]:
                        self.send_sparse_params_to_neighbors(neighbor_idx,self.round,
                            sync_buffer["flatten_selected_values"].buffer.cpu(),
                            sync_buffer["flatten_selected_indices"].buffer.cpu(),
                            sync_buffer["selected_shapes"],
                            self.worker.get_dataset_len())
                    else:
                        raise NotImplementedError
                
                    if self.worker_index == 5 and self.round <5 :
                        logging.info(f"Before [Round {self.round}] Worker 5 params: {flatten_params.buffer[:10]}..residual{self.residual}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")
 

                    if self.worker_index == 5 and self.round >50 and self.round<60:
                        logging.info(f"Before [Round {self.round}] Worker 5 params: {flatten_params.buffer[:10]}..residual{self.residual}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")

                    neighbor_cnt = 0
                    while self.worker.flag_neighbor_result_received_dict_for_flock:
                        neighbor_cnt += 1
                        neighbor_idx, cos_sim,sender_round = self.worker.aggregate_for_flock(self.compressor, sync_buffer["original_shapes"],flatten_params,self.to_store_agg)
                        # ② 对称 staleness 衰减
                        Δ        = self.round - sender_round           # 负=邻居超前
                        stale    = abs(Δ)
                        staleness  = 1.0 / (1.0 + stale)                # 简单双边衰减
                        self._update_neighbor_utility(neighbor_idx, cos_sim, staleness )

                    #   聚合完邻居后，聚合自己的参数
                    self.to_store_agg.add_(self.sent_part).div_(0.5*(neighbor_cnt+1))  # 累加自己的参数并进行push-sum平均
                    flatten_params.buffer.copy_(self.to_store_agg).add_(self.residual)  # 更新 flatten_params
                    sync_buffer["flatten_params"].unpack(params)  # 更新原始参数
                    if self.worker_index == 5 and self.round >50 and self.round<60:
                        logging.info(f"[Round {self.round}] Worker 5 params: {flatten_params.buffer[:10]}..residual{self.residual}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")

                    if self.worker_index == 5 and self.round <5:
                        logging.info(f"[Round {self.round}] Worker 5 params: {flatten_params.buffer[:10]}..residual{self.residual}...self.tostore{self.to_store_agg}...self.sent_part{self.sent_part}.")

                    self.round +=1
                self.test_and_log(iteration, epoch)

            self.send_notify_to_coordinator(0)



    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]


    def send_result_to_neighbors(self, receive_id, client_params1, local_sample_number):
        logging.debug("send_result_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_PARAMS_1, client_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)

    def send_sparse_params_to_neighbors(self, receive_id, round, client_sparse_params1, client_sparse_index1, selected_shapes, local_sample_number):
        logging.debug("send_sparse_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_SPARSE_PARAMS_1, client_sparse_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1, client_sparse_index1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        # Add last layer params to the message
        # message.add_params(MyMessage.MSG_ARG_KEY_LAST_LAYER_PARAMS, self.last_layer_params)
        message.add_params(MyMessage.MSG_ARG_KEY_LOCAL_ROUND, round)
        # 统一转成 1-D int32 Tensor；Python list 也行
        sel_shapes_tensor = torch.tensor(selected_shapes, dtype=torch.int32)
        message.add_params(MyMessage.MSG_ARG_KEY_SELECTED_SHAPES, sel_shapes_tensor)
        self.send_message(message)

    def send_quant_params_to_neighbors(self, receive_id, client_quant_params1, local_sample_number):
        logging.debug("send_quant_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_QUANT_PARAMS_1, client_quant_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)

    def send_sign_params_to_neighbors(self, receive_id, client_sign_params1, local_sample_number):
        logging.debug("send_sign_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_SIGN_PARAMS_1, client_sign_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)
    

    def send_notify_to_coordinator(self, receive_id=0):
        logging.debug("send_notify_to_coordinator. receive_id = %s, round: %s" % (str(receive_id), str(self.round)))
        message = Message(MyMessage.MSG_TYPE_CLIENT_TO_COORDINATOR, self.get_sender_id(), receive_id)
        self.send_message(message)


    def check_whether_all_clients_finish_receive(self):
        for rank, flag in self.flag_client_finish_dict.items():
            if not flag:
                return False
        return True


    def check_worker_finish_and_notify(self):
        if self.check_whether_all_clients_finish_receive():
            logging.debug(">>>>>>>>>>>>>>>COORDINATOR Receive all, ROUND %d finished!<<<<<<<<" %
                 (self.round))
            self.finish()
            # self._stop_event.set()
            # self._listen_thread.join()   # 如果你想等它优雅退出


    # ------------------------------------------------------------------
    # Hedonic utility 更新
    # ------------------------------------------------------------------
        # ------------------------------------------------------------------
    # Hedonic utility 更新（删除 loss 项） HEDONIC★
    # ------------------------------------------------------------------
    def _update_neighbor_utility(self, nbr: int, cos_sim: float, staleness: int):
        # update_time = time.time()
        """更新 util_cache，然后自调 util_threshold，使 good_set 占比≈30%。"""
        # 1. 计算当前邻居效用并做 EMA
        bw   = self.bw_norm[nbr]

        phase1_round = self.epochs * self.worker.num_iterations * self.PHASE1
        if self.round < phase1_round:
            t    = self.round 
            lam_bw  = self.lambda_bw0
            lam_sim = 0
        else:
            t_adj    = self.round - phase1_round
            lam_bw  = max(self.lambda_bw0 * np.exp(- t_adj / self.time_const), 0.01 * self.lambda_bw0)  # 防止过小
            lam_sim = self.lambda_sim0 * (1 - np.exp(- t_adj / self.time_const))
            # lam_bw = 0.5
            # lam_sim = 0.5
        util    = lam_bw * bw + lam_sim * cos_sim - self.lambda_dist * (1-staleness)
        self.util_cache[nbr] = (1 - self.util_alpha) * self.util_cache[nbr] + self.util_alpha * util
        if self.worker_index == 5:  # 只打印部分节点避免刷屏
            logging.info(f"[Round {self.round}] Worker {self.worker_index} update neighbor {nbr}: "
                     f"util={self.util_cache[nbr]:.4f}, bw={bw:.3f}, sim={cos_sim:.3f}, stale={staleness}"
                     f", lam_bw={lam_bw:.4f}, lam_sim={lam_sim:.4f}"
                     f", lam_bw * bw={lam_bw * bw:.4f}, lam_sim * cos_sim={lam_sim * cos_sim:.4f},self.lambda_dist * (1-staleness)={self.lambda_dist * (1-staleness):.2f}")

        # 2. 依据当前阈值划分 good / bad
        if self.util_cache[nbr] >= self.util_threshold:
            self.good_set.add(nbr); self.bad_set.discard(nbr)
        else:
            self.bad_set.add(nbr);  self.good_set.discard(nbr)

        # 3. 动态调整阈值：目标 good_ratio≈0.30 ±0.05
        outs = self.outs  # 固定拓扑列表
        if outs:
            good_ratio = len(self.good_set.intersection(outs)) / len(outs)
            if good_ratio < self.target_good_ratio - self.tolerance_ratio:
                self.util_threshold -= self.adjust_step   # good 太少 → 降低阈值
            elif good_ratio > self.target_good_ratio + self.tolerance_ratio:
                self.util_threshold += self.adjust_step   # good 太多 → 提高阈值

            # 4. 若阈值改变，需要重新划分 outs 中的成员
            for n in outs:
                if self.util_cache[n] >= self.util_threshold:
                    self.good_set.add(n); self.bad_set.discard(n)
                else:
                    self.bad_set.add(n);  self.good_set.discard(n)
        # update_time = time.time() - update_time
        # logging.info("update_neighbor_utility time %.4f" % update_time)

        # # 5. 调试日志
        # if self.worker_index == 5:  # 只打印部分节点避免刷屏
        #     logging.info(
        #         f"[Round {self.round}] thr={self.util_threshold:.3f}, "
        #         f"bw={bw:.3f}, sim={cos_sim:.3f}, stale={staleness}, "
        #         f"good_ratio={len(self.good_set.intersection(self.outs))/len(self.outs):.2f}, "
        #         f"good_set={sorted(self.good_set)}"
        #         f"[Worker {self.worker_index}] update {nbr}: util={self.util_cache[nbr]:.4f}, "
        #         f"thr={self.util_threshold:.2f}, good_ratio={good_ratio:.2f}")

    # def _update_neighbor_utility(self, nbr, cos_sim, staleness):
    #     bw   = self.bandwidth[self.worker_index][nbr]
    #     step = self.round
    #     lam_bw  = self.lambda_bw0 * np.exp(-step / self.time_const)
    #     lam_sim = self.lambda_sim0 * (1 - np.exp(-step / self.time_const))
    #     util = lam_bw * bw + lam_sim * cos_sim - self.lambda_dist * staleness  # 无 loss 项
    #     self.util_cache[nbr] = (1 - self.util_alpha) * self.util_cache[nbr] + self.util_alpha * util

    #     # -------- 维护 good_set / bad_set --------
    #     if self.util_cache[nbr] >= self.util_threshold:
    #         if nbr in self.bad_set:
    #             self.bad_set.remove(nbr)
    #             self.good_set.add(nbr)
    #     else:
    #         if nbr in self.good_set:
    #             self.good_set.remove(nbr)
    #             self.bad_set.add(nbr)
    #     # if self.worker_index == 5:
    #     logging.info("Worker %d update neighbor %d utility: %.4f, good_set: %s, bad_set: %s" %
    #                  (self.worker_index, nbr, self.util_cache[nbr],
    #                   self.good_set, self.bad_set))

    def _choose_neighbor(self):                # HEDONIC★ 三阶段 + 单 send + 时间窗
        choose_time = time.time()
        """选择一个邻居进行发送。
        · 阶段①(前 15%)  : 纯均匀随机  —— 充分探索 / 快速扩散
        · 阶段②(15%~70%): 偏好 good_idx —— Soft‑max + ε/|bad|
        · 阶段③(>=70%)  : 只在 good_idx Soft‑max，ε→0
        同时始终保证  time_window  内每个 outs 至少被选一次。"""
        outs  = self.outs
        cur_r = self.round

        # 0️⃣  强连通保障：优先处理过期邻居（在 outs 中）
        overdue = [n for n in outs if cur_r - self.last_chosen_round[n] >= self.time_window]
        if overdue:
            choice = np.random.choice(overdue)
            self.last_chosen_round[choice] = cur_r

            # if self.worker_index == 5:
            #     logging.debug(f"[Round {self.round}] Overdue....Worker 5 chose neighbor {choice} ")
            return int(choice)
        # choice = np.random.choice(outs)
        # self.last_chosen_round[choice] = cur_r
        # return int(choice)

        # 1️⃣ 计算训练进度比例 progress ∈ (0,1)
        total_rounds = self.epochs * self.worker.num_iterations + 1e-8
        progress = cur_r / total_rounds

        PHASE1 = self.PHASE1   # <15% : 全随机
        PHASE3 = self.PHASE3   # >70% : 只 good

        # (A) 前期：带宽主导探索
        if progress < PHASE1:
            # if self.worker_index == 5:
            #     logging.info(f"[Round {self.round}] Worker {self.worker_index} in Phase 1, self.util_cache: {self.util_cache[self.good_set]}")
            logits = self.bw_norm[outs]             # 已 0-1 归一化
            probs  = np.exp(logits - logits.max())
            probs  = probs / probs.sum()
            choice = np.random.choice(outs, p=probs)
            self.last_chosen_round[choice] = cur_r
            return int(choice)
            # choice = np.random.choice(outs)
            # self.last_chosen_round[choice] = cur_r
            # # if self.worker_index == 5:
            # #     logging.debug(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
            # return int(choice)


        # choice = np.random.choice(outs)
        # self.last_chosen_round[choice] = cur_r
        # return int(choice)


        # 构造 good / bad 列表（均在 outs 内）
        good_idx = [n for n in outs if n in self.good_set]
        bad_idx  = [n for n in outs if n in self.bad_set]

        # (B) 后期：good_only & ε → 0
        if progress >= PHASE3 and good_idx:
            eps     = 0.05
            # logits = self.util_cache[good_idx] - np.max(self.util_cache[good_idx])
            # probs  = np.exp(logits); probs = probs / probs.sum()
            # choice = np.random.choice(good_idx, p=probs)
            # self.last_chosen_round[choice] = cur_r
            # # if self.worker_index == 5:
            # #     logging.info(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
            # return int(choice)

        if self.round == self.epochs * self.worker.num_iterations * self.PHASE1:
            if self.worker_index == 5:
                logging.info(f"[Round {self.round}] Worker {self.worker_index} in Phase 2, self.util_cache: {self.util_cache[good_idx]}")
        # (C) 中期：Soft‑max good + ε 均匀 bad
        eps     = self.util_eps                       # 典型 0.02
        prob_g, prob_b = np.array([]), np.array([])

        if good_idx:
            logits = self.util_cache[good_idx]
            logits = logits - logits.max()
            w_g    = np.exp(logits)
            prob_g = (1 - eps) * w_g / w_g.sum()
        if bad_idx:
            prob_b = np.ones(len(bad_idx)) * (eps / len(bad_idx))

        all_probs = np.concatenate([prob_g, prob_b]); all_idxs = good_idx + bad_idx
        all_probs = all_probs / all_probs.sum()
        choice    = np.random.choice(all_idxs, p=all_probs)
        self.last_chosen_round[choice] = cur_r
        # if self.worker_index == 5:
        #     logging.info(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
        return int(choice)

    def my_get_out_neighbor_idx_list(self, worker_idx: int):
        """
        返回指定节点可发送的邻居列表。
        规则：同一行带宽 > 0 且非对角元素即为出边。
        若带宽矩阵已归一化，0 表示不可达。
        """
        assert hasattr(self, "bandwidth"), "请先生成并归一化 self.bandwidth"
        row = self.bandwidth[worker_idx]
        # 取带宽正值且列索引 ≠ 自己
        outs = [j for j, bw in enumerate(row) if (j != worker_idx) and (bw > 0)]
        return outs




