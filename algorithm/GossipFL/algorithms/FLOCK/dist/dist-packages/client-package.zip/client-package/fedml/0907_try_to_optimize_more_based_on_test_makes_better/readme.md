we find that 1 test / epoch has better accuracy than 1 test / 5 epoch.
This means that the test can allow the add_result_for_flock to aggregate more params from neighbors. and accelerates the mixture process.

This also means that the uncompressing speed is slower than the receiving, and causes backpressure.
We need to accelerate the uncompressing and receiving.


today's log:
-   FLOCK_30node_testalong_20250907_1.log
-   -   client_num_in_total 30, writting to files
-   FLOCK_30node_testalong_20250907_2.log
-   -   client_num_in_total 30, testing 1 / 5 epochs
-   FLOCK_30node_testalong_20250907_3.log
-   -   client_num_in_total 30, testing 1 / 1 epoch