import logging
import time
from copy import deepcopy
import torch
from torch import nn
import traceback
from mpi4py import MPI
import threading

from utils.timer import Timer
# from fedml_api.utils.timer_with_cuda import Timer
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from algorithms.baseDecent.decentralized_worker import BaseDecentralizedWorker

class DecentralizedWorker(BaseDecentralizedWorker):
    def __init__(self, worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics):
        """
            The `compression` method should be specified in `args`.
        """
        self.worker_index = worker_index
        self.topology_manager = topology_manager
        self.refresh_gossip_info()
        #===========================================================================
        super().__init__(worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics)

        # =================================================
        # Specilaized for SAPS_FL
        # ============================================================
        self.param_groups = self.model_trainer.param_groups
        self.param_names = self.model_trainer.param_names

        self._shapes, self._total_len = self.init_flatten_params_shapes()


        # CPU 双缓冲
        self._rx_lock = threading.Lock()
        # 初始化 CPU 双缓冲（pinned）
        _cpu_buf = torch.zeros(self._total_len, dtype=torch.float32, device="cpu")
        self._rx_buf_a = _cpu_buf.pin_memory() if torch.cuda.is_available() else _cpu_buf
        self._rx_buf_b = torch.zeros_like(self._rx_buf_a)
        # self._rx_buf_a = torch.zeros(self._total_len, dtype=torch.float32, device="cpu").pin_memory()
        # self._rx_buf_b = torch.zeros_like(self._rx_buf_a).pin_memory()
        self._rx_active = self._rx_buf_a
        self._rx_standby = self._rx_buf_b


        # ---- 邻居权重累加缓冲（与 _rx_* 一一对应）----
        _wcpu = torch.zeros(self._total_len, dtype=torch.float32, device="cpu")
        self._w_buf_a = _wcpu.pin_memory() if torch.cuda.is_available() else _wcpu
        self._w_buf_b = torch.zeros_like(self._w_buf_a)
        self.neighbor_total_weight_active = self._w_buf_a
        self.neighbor_total_weight_standby = self._w_buf_b

        # === H2D 重叠：独立复制流 + 可重用 GPU 侧 staging buffer + 事件 ===
        self._use_cuda = torch.cuda.is_available() and ("cuda" in str(self.device))
        self._copy_stream = torch.cuda.Stream(device=self.device) if self._use_cuda else None
        self._h2d_buf = None                # GPU 端临时缓冲，按需懒分配并复用
        self._h2d_event = torch.cuda.Event() if self._use_cuda else None
        # 若需要把“权重”也搬到 GPU 做归一化，可复用一块 staging
        self._h2d_wbuf = None

        # Two-phase nonblocking merge state
        self._merge_pending = False                        # there is an in-flight staged copy
        self._ready_inflight = None                        # CPU source waiting to be zeroed after apply
        self._wready_inflight = None


        # 训练步后记录的扁平参数快照（CPU）：由 manager 在 run_sync 内赋值
        self.step_param_cpu = None

        # 压缩器 & 即时评估回调（由 manager 注入）
        self._rx_comp = None
        self._eval_cb = None

        self.number_of_neighbor_param_received = 0
        self.neighbor_weight = 0.5
        self.total_neighbor_weight = 0.0
        self.is_last_step = False  # 是否为最后一个训练步

        # 统计计数器
        self.stat_rx_msgs = 0
        self.stat_batch_swaps = 0
        self.stat_batch_merge_h2d_time = 0.0
        self.stat_sim_computed = 0  # 已计算的相似度条数

    def set_rx_compressor(self, compressor):
        """由 manager 调用，把 compressor 注入到 worker（用于本地前移解压）。"""
        self._rx_comp = compressor

    def set_eval_callback(self, cb):
        """
        由 manager 注入回调，用于在接收线程里即时完成：
          - 对称 staleness 衰减
          - self._update_neighbor_utility(...)
        cb: Callable(neighbor_idx: int, sender_round: int, cos_sim: float) -> None
        """
        self._eval_cb = cb


    # ==============================================================================
    # Specilaized for SAPS_FL

    # file input implementation        
    def add_result_for_flock(self, worker_index, sender_round, updated_information):
        """
        1) Decode to CPU (sparse indices/values)
        2) Compute cosine similarity against the latest self.step_param_cpu
        3) index_add_ 0.5 * q_values into the CPU active buffer (_rx_active)
        4) Fire callback for staleness/utility update
        5) Push a flag for the manager/merger to stage
        """
        logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
            self.worker_index, worker_index, sender_round))
        
        with torch.no_grad():  # ← 新增，确保不跟踪计算图
            logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
                self.worker_index, worker_index, sender_round))

            if self._rx_comp is None:
                raise RuntimeError("RX compressor not set. Call set_rx_compressor() in manager before training.")

            # —— 解压到 CPU（门面 API）——
            q_values = q_indices = idx = local_slice = neigh_slice = inc = None
            try:
                # (1) uncompress
                q_values, q_indices = self._rx_comp.decode_sparse_msg(updated_information, self._shapes)
                idx = q_indices.to(dtype=torch.long)  # 索引保证 
                cos_sim = 0
                # (2) calculate sim
                if (self.step_param_cpu is not None) and (self.step_param_cpu.numel() == self._total_len):
                    local_slice = self.step_param_cpu[idx]
                    neigh_slice = q_values.to(local_slice.dtype)
                    EPS = 1e-8
                    denom = local_slice.norm() * neigh_slice.norm() + EPS
                    if float(denom) > 0.0:
                        cos_raw = torch.dot(local_slice, neigh_slice) / denom
                        COS_MIN, COS_MAX = 0.9, 1.0
                        cos_raw = torch.clamp(cos_raw, min=COS_MIN, max=COS_MAX)
                        cos_sim = float((cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS))
                else:
                    cos_sim = 0
                self.stat_sim_computed += 1    

                # (3) sum on CPU（w =  0.5）
                # inc = (self.neighbor_weight * q_values).to(self._rx_active.dtype)
                # # wvec：与 idx 等长的权重向量（每个出现 +0.5）
                # wvec = torch.full_like(q_values,
                #                     fill_value=float(self.neighbor_weight),
                #                     dtype=self._rx_active.dtype,
                #                     device=self._rx_active.device)

                # with self._rx_lock:
                #     self._rx_active.index_add_(0, idx.long(), inc)
                #     self.neighbor_total_weight_active.index_add_(0, idx.long(), wvec)
                #     self.number_of_neighbor_param_received += 1
                #     self.stat_rx_msgs += 1
                # inc = (self.neighbor_weight * q_values).to(self._rx_active.dtype)
                # wvec：与 idx 等长的权重向量（每个出现 +0.5）
                # wvec = torch.full_like(q_values,
                #                     fill_value=float(self.neighbor_weight),
                #                     dtype=self._rx_active.dtype,
                #                     device=self._rx_active.device)

                with self._rx_lock:
                    self._rx_active.index_add_(0, idx.long(), q_values)
                    # self.neighbor_total_weight_active.index_add_(0, idx.long(), wvec)
                    self.neighbor_total_weight_active[q_indices] += self.neighbor_weight
                    self.number_of_neighbor_param_received += 1
                    self.stat_rx_msgs += 1
                # with self._rx_lock:
                #     self._rx_active.index_add_(0, idx, inc)
                #     self.number_of_neighbor_param_received += 1
                #     self.stat_rx_msgs += 1
                #     self.total_neighbor_weight += self.neighbor_weight

                # (4) update staleness + utility
                if callable(self._eval_cb):
                    try:
                        self._eval_cb(int(worker_index), int(sender_round), float(cos_sim))
                    except Exception:
                        logging.exception("eval callback failed in add_result_for_flock")

            finally:
                # —— 及时释放局部张量引用，降低 RSS 峰值 —— 
                # 这些 del 只删除 Python 引用；真实内存释放取决于是否还有别的引用
                for _obj in (idx, inc, local_slice, neigh_slice, q_values, q_indices):
                    try:
                        del _obj
                    except Exception:
                        pass
        

    # -------------------- Two-phase nonblocking merge: Stage (A) + Apply (B) --------------------
    def stage_merge_nonblocking(self, flatten_params: TensorBuffer) -> bool:
        """
        Phase-A (nonblocking): if new data exists and no in-flight merge,
        swap CPU dual buffers and launch pinned-CPU -> GPU async copy on a dedicated stream.
        Return True if a stage is initiated; otherwise False.
        """
        # no new data or in-flight merge exists
        if (self.number_of_neighbor_param_received == 0) or self._merge_pending:
            return False

        # swap CPU buffers; get ready snapshot
        with self._rx_lock:
            ready = self._rx_active
            self._rx_active, self._rx_standby = self._rx_standby, self._rx_active
            self._rx_active.zero_()

        # drain trigger queue
        try:
            if self.number_of_neighbor_param_received > 0:
                self.number_of_neighbor_param_received = 0
                self.total_neighbor_weight = 0.0
        except Exception:
            pass

        gpu_buf = flatten_params.buffer

        # CPU-only training path: directly add on CPU (no H2D)
        if (not self._use_cuda) or (not gpu_buf.is_cuda):
            gpu_buf.add_(ready.to(dtype=gpu_buf.dtype, copy=False))
            ready.zero_()
            self.stat_batch_swaps += 1
            return True

        # CUDA path: launch async H2D copy on the copy-stream; do NOT modify params here
        if (self._h2d_buf is None or
                self._h2d_buf.dtype != gpu_buf.dtype or
                self._h2d_buf.numel() != gpu_buf.numel() or
                self._h2d_buf.device != gpu_buf.device):
            self._h2d_buf = torch.empty_like(gpu_buf)

        with torch.cuda.stream(self._copy_stream):
            # ready must be pinned CPU
            self._h2d_buf.copy_(ready.view_as(self._h2d_buf), non_blocking=True)
            self._h2d_event.record(self._copy_stream)

        self._ready_inflight = ready
        self._merge_pending = True
        self.stat_batch_swaps += 1
        return True

    def apply_pending_merge(self, flatten_params: TensorBuffer) -> bool:
        """
        Phase-B (safe point on training stream): wait for the copy event then
        add the staged buffer into GPU params; zero the CPU source; clear the state.
        Return True if applied; otherwise False.
        """
        if not self._merge_pending:
            return False

        gpu_buf = flatten_params.buffer
        if (self._use_cuda and gpu_buf.is_cuda):
            torch.cuda.current_stream().wait_event(self._h2d_event)
            gpu_buf.add_(self._h2d_buf)
        else:
            # CPU-only fallback (should already be done in stage)
            pass

        if self._ready_inflight is not None:
            self._ready_inflight.zero_()
            self._ready_inflight = None

        self._merge_pending = False
        return True



    # -------------------- Backward-compatible aggregate (wraps Stage+Apply) --------------------
    # def aggregate_for_flock(self, compressor, selected_shapes, flatten_params):
    #     """
    #     Kept for compatibility. It will try to Stage then immediately Apply.
    #     Prefer calling stage_merge_nonblocking() in a merger thread and
    #     apply_pending_merge() at training safe points for real overlap.
    #     """
    #     staged = self.stage_merge_nonblocking(flatten_params)
    #     if staged:
    #         self.apply_pending_merge(flatten_params)
    #     # Pop one trigger item to keep old callers happy
    #     if self.flag_neighbor_result_received_dict_for_flock:
    #         neighbor_idx, sender_round = self.flag_neighbor_result_received_dict_for_flock.pop(0)
    #     else:
    #         neighbor_idx, sender_round = None, -1
    #     return neighbor_idx, 1.0, sender_round                    


    # file output implementation
    def aggregate_for_flock(self, compressor, selected_shapes,sync_buffer):
        # start_time = time.time()
        if self.number_of_neighbor_param_received == 0:
            return
        
        ready = None
        add_vec = None
        try:
            with self._rx_lock:
                ready = self._rx_active
                ready_weight = self.neighbor_total_weight_active
                self.neighbor_total_weight_active, self.neighbor_total_weight_standby = self.neighbor_total_weight_standby, self.neighbor_total_weight_active
                self.neighbor_total_weight_active.zero_()
                self._rx_active, self._rx_standby = self._rx_standby, self._rx_active
                self._rx_active.zero_()
                self.number_of_neighbor_param_received = 0
                self.total_neighbor_weight = 0.0
                

            # # 合并（H2D + add_）
            # t0 = time.time()
            # gpu_buf = flatten_params.buffer
            # add_vec = ready.to(device=gpu_buf.device, dtype=gpu_buf.dtype, non_blocking=True)
            # gpu_buf.add_(add_vec)
            # h2d_t = time.time() - t0

            # 合并（H2D + add_），使用 pinned+non_blocking + 独立 CUDA 流
            t0 = time.time()
            
            
            # local_gpu_buf = sync_buffer["flatten_selected_values"].buffer
            # local_gpu_idx = sync_buffer["flatten_selected_indices"].buffer
            gpu_buf = sync_buffer["flatten_params"].buffer

            # CPU-only 路径（例如在 CPU 训练或无 CUDA 时）
            if (not self._use_cuda) or (not gpu_buf.is_cuda):
            # if (not self._use_cuda):
                add_vec_cpu = ready.to(dtype=gpu_buf.dtype, copy=False) #这里应该是加上，不上赋值
                add_w_vec_cpu = ready_weight.to(dtype=gpu_buf.dtype, copy=False)
                add_w_vec_cpu.add_(self.neighbor_weight)  # 加上自己的权重 0.5
                gpu_buf.add_(add_vec_cpu)
                gpu_buf.div_(add_w_vec_cpu.clamp_min_(1e-6))  # 归一化
                ready.zero_()
                ready_weight.zero_()
                h2d_t = time.time() - t0
            else:
            #     logging.info(f"[rank {self.worker_index}] use_cuda={self._use_cuda}, "
            #  f"params_is_cuda={gpu_buf.is_cuda}")
                # 1) 懒分配并复用 GPU staging 缓冲，避免频繁分配
                if (self._h2d_buf is None or
                    self._h2d_buf.dtype != gpu_buf.dtype or
                    self._h2d_buf.numel() != gpu_buf.numel() or
                    self._h2d_buf.device != gpu_buf.device):
                    self._h2d_buf = torch.empty_like(gpu_buf)
                if (self._h2d_wbuf is None or
                    self._h2d_wbuf.dtype != gpu_buf.dtype or
                    self._h2d_wbuf.numel() != gpu_buf.numel() or
                    self._h2d_wbuf.device != gpu_buf.device):
                    self._h2d_wbuf = torch.empty_like(gpu_buf)

                # 2) 在独立复制流上发起 H2D：从 pinned CPU -> GPU
                #    注意：源 ready 必须为 pinned（上文 __init__ 已 pin_memory()）
                with torch.cuda.stream(self._copy_stream):
                    # 拷贝仅在 dtype 匹配时真正 zero-copy DMA；若 dtype 不同，请统一模型与缓冲 dtype
                    # gpu_buf = sync_buffer["flatten_params"].buffer.zero_().index_add_(0, local_gpu_idx.long(), local_gpu_buf)
                    # gpu_buf = sync_buffer["flatten_params"].buffer.zero_().index_add_(0, local_gpu_idx.long(), ready.to(dtype=local_gpu_buf.dtype, copy=False))
                    # wvec = torch.full_like(local_gpu_buf,
                    #         fill_value=float(self.neighbor_weight),
                    #         dtype=gpu_buf.dtype,
                    #         device=gpu_buf.device)
                    # ready_weight = ready_weight.index_add_(0, local_gpu_idx.buffer.long(), wvec)

                    self._h2d_buf.copy_(ready.view_as(self._h2d_buf), non_blocking=True)
                    # self._h2d_buf.index_add_(0, local_gpu_idx.long(), local_gpu_buf)
                    self._h2d_wbuf.copy_(ready_weight.view_as(self._h2d_wbuf), non_blocking=True)
                    self._h2d_wbuf.add_(self.neighbor_weight)  # 加上自己的权重 0.5
                    # self._h2d_wbuf.index_add_(0, local_gpu_idx.long(), wvec)
                    self._h2d_event.record(self._copy_stream)

                # 3) 让默认流等待复制完成，再执行就地加和
                torch.cuda.current_stream().wait_event(self._h2d_event)
                gpu_buf.add_(self._h2d_buf)
                gpu_buf.div_(self._h2d_wbuf.clamp_min_(1e-6))
                h2d_t = time.time() - t0

            # 统计
            self.stat_batch_swaps += 1
            self.stat_batch_merge_h2d_time += float(h2d_t)

            # 清空 ready 内容，避免旧数据叠加
            ready.zero_()
            ready_weight.zero_()
        finally:
            # —— 释放局部引用 —— 
            try: del add_vec
            except NameError: pass
            try: del ready
            except NameError: pass




    def init_flatten_params_shapes(self):
        params, _shapes = get_data(self.param_groups, self.param_names, is_get_grad=False)
        _total_len = int(sum(p.numel() for p in params))
        return _shapes, _total_len


    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]
        self.in_neighbor_idx_list = self.topology_manager.get_in_neighbor_idx_list(self.worker_index)









