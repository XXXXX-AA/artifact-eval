### 首先要在每次cluster更新时，通知所有cluster内的节点
要点是要保证所有的cluster内的节点是同步的。因此增加一个新的消息类型，和handler
#### （1）cluster合并
#### （2）cluster加入
#### （3）cluster离开

###   2025/6/6
#### 增加cluster广播



### 2025/6/24
#### 
#### 功能，coalition公式，-loss+bw+sim-RoundDist




## 2025/6/25
#### （1）增加本地buffer+senderID，用来存储邻居发来的参数→本来就有的，是
'''
self.worker.add_result(sender_id, msg_params)
    
def add_result(self, worker_index, updated_information):
    self.worker_result_dict[worker_index] = updated_information
    self.flag_neighbor_result_received_dict[worker_index] = True
'''


#### 增加的代码如下：
'''
BASEDECENT/decentralized_worker.py
self.flag_neighbor_result_received_dict_for_flock = deque()


    # for flock
    def add_result_for_flock(self, worker_index, updated_information):
        self.worker_result_dict[worker_index] = updated_information
        self.flag_neighbor_result_received_dict_for_flock.append(worker_index)



    # for flock
    def aggregate_for_flock(self):
        start_time = time.time()
        model_list = []
        training_weights = 0

        #  TODO, There are some bugs
        model_list.append((0.5, self.get_model_params()))

        if self.flag_neighbor_result_received_dict_for_flock:
            neighbor_idx = self.flag_neighbor_result_received_dict_for_flock.popleft()
            model_list.append((0.5, self.worker_result_dict[neighbor_idx]))
            training_weights += 0.5

        training_weights = 1.0
        logging.debug("len of self.worker_result_dict[idx] = " + str(len(self.worker_result_dict)))

        # logging.debug("################aggregate: %d" % len(model_list))
        (num0, averaged_params) = model_list[0]
        for k in averaged_params.keys():
            # averaged_params[k] = averaged_params[k] * self.local_sample_number / training_num
            for i in range(0, len(model_list)):
                local_sample_number, local_model_params = model_list[i]
                # w = local_sample_number / training_weights
                if i == 0:
                    averaged_params[k] = local_model_params[k] * local_sample_number
                else:
                    averaged_params[k] += local_model_params[k] * local_sample_number
            averaged_params[k] /= training_weights

        end_time = time.time()
        logging.debug("aggregate time cost: %d" % (end_time - start_time))
        return averaged_params

'''

#### 改变SAPS的逻辑
##### 1、增加self.ifStop = False，在全部训练结束后通知coo
##### # 训练循环结束后 self.send_message_to_coordinator(MSG_TYPE_FINISHED)
##### 2、删除所有的

    self.start_epoch_event.clear()
    self.sync_receive_all_event.clear()
##### 3、每次训练完毕后不需要通知Coordinator，修改一下代码为：
    #self.test_and_send_to_coordinator(iteration, epoch)
    self.worker.test(self.epoch, self.test_tracker, self.metrics)

##### 4、在本worker结束所有epoch的训练之后，向coordinator发送结束信息，并继续监听，等待coordinator的结束信息。因此需要增加一个结束标志位
（1）增加结束标志位

    # whether all workers finised
    self.ifStop = False
（2）重写以下函数，当给coordinator发notification时，即代表本地训练结束，并等待全局结束信息
    def send_notify_to_coordinator(self, receive_id=0):
        logging.debug("send_notify_to_coordinator. receive_id = %s, round: %s" % (str(receive_id), str(self.global_round_idx)))
        message = Message(MyMessage.MSG_TYPE_CLIENT_TO_COORDINATOR, self.get_sender_id(), receive_id)
        self.send_message(message)



### 2025-6-27
##### 改变了顺序，改变了aggregation、uncompress、uncompress_direct

### 2025-6-28 完成了异步训练。今天的任务是，local——gossip。应该怎么做呢？
1、每个节点应该有一个local视角。那么就是根据Gossipfl的矩阵，给每个节点单独的一行就行了。进行固定的存储。
2、coordinator需要生成这个矩阵，然后发送每一行给各个节点。
2、然后每个节点每轮随机选择。


### 2025-6-30 彻底完成了编码和优化
（1）存在的问题：
    个人感觉是每个节点等待解压锁的过程拖慢了整体节奏。如果在收到的同时就解压缩，应该可以提升一定的时间。
    目前的聚合过程很耗费时间。



### 2025-07-01
#### Finished implementing the FLOCK system.
#### (1) Bubble:        GossipFL √, FLOCK ×.
#### (2) Efficiency:    260 mins for GossipFL, 40 mins for FLOCK.
#### (3) Acc1:          99% for GossipFL,     98% for FLOCK.
#### Todo: Fine tune the neighbor choosing hyperparameters, to improve Acc1.


### 2025-07-02
#### 发现问题可能出现在，相似性的取值一直在0.984~0.987之间，差异太小不可区分，因此修改了以下代码来增强差异，对应的日志文件是0.8（FLOCK-0702-4-ratio05-lam0505-enlargesim），0.6（FLOCK-0702-5-ratio05-lam0505-enlargesim-alpha06）:
#### 结果总结，确实98%以上的节点多了，但是也没有多太多，还是差异太小。0.6比0.8的准确率稍微高一点。
        local_slice, neigh_slice 已经是一一对应的稀疏向量
        cos_raw = torch.dot(local_slice, neigh_slice) / (
                    local_slice.norm() * neigh_slice.norm() + 1e-8)

        # L2 差 → 对数压缩到 (0,∞)，误差小 ⇒ 值大
        l2 = torch.norm(local_slice - neigh_slice) / (
                torch.norm(local_slice) + 1e-8)
        l2_scaled = -torch.log10(l2 + 1e-8)          # 0.01→2, 0.001→3 …

        ALPHA = 0.8      # 方向为主，幅值辅助。可在 0.7~0.9 间调
        cos_sim = (ALPHA * cos_raw + (1-ALPHA) * (l2_scaled / 4.0)).item()
####  以上方法的cos_sim取值范围仍然差异很小。因此，直接使用min和max值来将sim映射到【0,1】，代码如下，对应日志文件是（FLOCK-0702-6-ratio05-lam0505-enlargesim-minmax）：
        COS_MIN = 0.984
        COS_MAX = 0.987
        EPS     = 1e-8                 # 防止除 0 / 负值

        # 原始 cosine（float）
        cos_raw = torch.dot(local_slice, neigh_slice) / (
                local_slice.norm() * neigh_slice.norm() + EPS)

        # ---------- 线性拉伸 ----------
        if cos_raw < COS_MIN:
            cos_raw = COS_MIN
        elif cos_raw > COS_MAX:
            cos_raw = COS_MAX
        cos_scaled = (cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS)
        # 若希望严格落在 [0,1]，再夹一下
        cos_sim = torch.clamp(cos_scaled, 0.0, 1.0).item()

#### TODO:
#### 这样在刚进入低9个epoch的时候会变慢。因为当前设置的权重是0.5+0.5.在下一次训练时，将权重改成退火.FLOCK-0702-7-ratio05-enlargesim-minmax
#### 结论，从50epoch开始准确率大幅度提升，而此时恰好是sim的权重达到最大的时刻。这说明，在初期达到峰值后需要迅速的提升sim的权重。


## 2025-07-03
### FLOCK-0703-1-minbw001，将
lam_bw  = max(self.lambda_bw0 * np.exp(- t_adj / self.time_const), 0.1 * self.lambda_bw0)
改为
    lam_bw  = max(self.lambda_bw0 * np.exp(- t_adj / self.time_const), 0.01 * self.lambda_bw0)  # 防止过小
#### 结论是，无论怎么调整，仍然无法改变98%的限制。我感觉可能是timewindow的问题，因此在明天，将timewindow调整成与gossipfl类似（3）我们先调整成math.ceil(3 * math.log(size)).


## 2025-0704
### FLOCK-0704-1-time_window3lgn.log，尝试1000epoch，看一下最终
我们先调整成math.ceil(3 * math.log(size)).
        self.util_alpha     = 0.2                           # EMA 衰减 0.1
        self.util_eps       = 0.5                          # ε‑greedy 0.05(630-4)  0.1(0701-1)
        self.lambda_bw0     = 3.0                           # 1 3
        self.lambda_sim0    = 0.8                           # 0.2.  0.8 2
        # self.lambda_loss    = 0.2
        self.lambda_dist    = 0.05
        self.time_const     = 1.0 * self.epochs                           # 退火常数 200 0.5 0.7
        # -------- 阈值 + 时间窗 -------- HEDONIC★
        self.util_threshold = 0.0                      # 初始阈值
        self.target_good_ratio = 0.5                   # 期望 good_set ≈ 30% of outs
        self.tolerance_ratio   = 0.05                  # 可接受波动 ±5%
        self.adjust_step       = 0.002                 # 每次阈值调整幅度 0.07
        # self.time_window    = getattr(args, "time_window", 2*size)   # 至少每 50 轮被选一次 2/3 * size
        self.time_window = int(np.ceil(3 * np.log(size)))


    （2）修改了三阶段逻辑。
        if progress >= PHASE3 and good_idx:
            eps     = 0.05
            # logits = self.util_cache[good_idx] - np.max(self.util_cache[good_idx])
            # probs  = np.exp(logits); probs = probs / probs.sum()
            # choice = np.random.choice(good_idx, p=probs)
            # self.last_chosen_round[choice] = cur_r
            # # if self.worker_index == 5:
            # #     logging.info(f"[Round {self.round}] Worker 5 chose neighbor {choice} ")
            # return int(choice)

### GPT认为是连通性不足导致手敛变慢，util_eps=0.3，self.target_good_ratio = 0.3。 退火速度要慢，让utility有变化，让节点可以和更多的节点沟通，因此还要降低退火速度
        self.util_alpha     = 0.2                           # EMA 衰减 0.1
        self.util_eps       = 0.5                          # ε‑greedy 0.05(630-4)  0.1(0701-1)
        self.lambda_bw0     = 3.0                           # 1 3
        self.lambda_sim0    = 0.8                           # 0.2.  0.8 2
        # self.lambda_loss    = 0.2
        self.lambda_dist    = 0.05
        self.time_const     = 1.0 * self.epochs                           # 退火常数 200 0.5 0.7
        # -------- 阈值 + 时间窗 -------- HEDONIC★
        self.util_threshold = 0.0                      # 初始阈值
        self.target_good_ratio = 0.5                   # 期望 good_set ≈ 30% of outs
        self.tolerance_ratio   = 0.05                  # 可接受波动 ±5%
        self.adjust_step       = 0.002                 # 每次阈值调整幅度 0.07
        # self.time_window    = getattr(args, "time_window", 2*size)   # 至少每 50 轮被选一次 2/3 * size
        self.time_window = int(np.ceil(3 * np.log(size)))


### 修改参数 util_eps=0.5→0.3，self.target_good_ratio = 0.5→0.3 ， self.PHASE3 = 0.7→0.6 （FLOCK-0704-3-hyperchange）

### 彻底完全随机试一下。
FLOCK-0704-4-fullrandom


!!!!!!!
### 重大发现，需要将non-iid环境改成partition_method = "noniid-#label2"
（1）CHOCO_SGD-0704-2-label2.log

（2）将compressor.py文件中的minmax方法改回最初始的方法。然后运行FLOCK-0704-3-label2.log

echo "./launch_mpi_based.sh > MNIST/FLOCK-0704-3-label2.log 2>&1 & disown"   | at now + 4 hours


### 2025-07-05
又跑了GossipFL的实验，发现在极端non-iid的情况下，GossipFL远远超过其他方案的精度。查找原因。
（3）GossipFL-0705-1-label2
（4）GossipFL-0705-2-label2


！！！在咖啡馆，重大发现
### GossipFL好的原因可能是增加了误差累积，而我没有实现。
修改如下：
（1）在decentralized_worker_manager_FLOCK中，增加残差记录
    # ---------- Error-Feedback 变量 ----------
        self.residual     = None   # r_i，存放未发送的差分
        self.prev_params  = None   # θ_prev，用来计算本轮真实差分
（2）在主循环的压缩前中，累加上残差：

    # ② 初始化 residual / prev_params ── 首轮进入
    if self.residual is None:
        self.residual    = torch.zeros_like(flatten_params.buffer)  # 与模型同形
        self.prev_params = flatten_params.buffer.clone()            # 存首轮基准

    # -----------------------------------------------------------
    # ★ ③ 计算“真实差分 + 上轮残差”
    delta_true     = flatten_params.buffer - self.prev_params        # θ_i - θ_prev
    delta_send     = delta_true + self.residual                      # 加上残差补偿
    #   注意：此时 self.prev_params 仍是上一轮模型
    # -----------------------------------------------------------
_FLOCK_8_原来跟本没压缩-测试前
（3）在住循环的压缩后，计算残差：
    
 (4) 结论：经过对比，聚合残差的方法，在极端non-iid的场景中，会由于节点之间的残差过于不同而出现正负抵消的情况，导致收敛速度非常低。-----结论就是---
（5）残差结论：最好是聚合param，但是带有残差的补偿

### 2025-07-06 带有error compensation的param aggregation
#### 原来的实现机制是，在聚合参数时，首先让flatten_params*0.5，这是不对的，应该只是将压缩后的内容*0.5，然后再添加上没有压缩的内容。
(1) 回退到没有传输差值的代码。
-   decentralized_worker_manager_FLOCK_5_0705_residual
-   decentralized_worker_FLOCK_6_0705累计有问题
-   compressor_FLOCK_6_0705累计有问题
（2）decentralized_worker_manager：
-   -   1，在train_one_step之前，获取param和flatten_params。
-   -   2，在train_one_step之后，保存flatten_params，
-   -   3，在压缩后，计算残差，并在本地保留发送的数据版本

（3）我发现，gossipfl的randomk实现，根本没有压缩到0.01，反而是发送了0.99的参数。因此也没有必要进行误差补偿了。回退到之前的代码。只稍微修改一下原来的代码即可。
我先修改GossipFL实际压缩0.01测试一下准确率。（详见MNIST/Gossip-0706-1-randomk001.log，准确率和收敛速度急剧下降），提升到0.99后又回升了（MNIST/Gossip-0706-2-randomk099.log） best acc1: 199,99.15857142857143,128.36984999999999

(4)重新复制了0704的代码
进行了两个测试：
-   FLOCK-0706-7-realpush-sum-randomk099  
参数：
当前参数如下：self.util_cache     = np.zeros(size)                # 邻居效用 EMA
        self.util_alpha     = 0.2                           # EMA 衰减 0.1
        self.util_eps       = 0.5                          # ε‑greedy 0.05(630-4)  0.1(0701-1) 0.5(0706)
        self.lambda_bw0     = 3.0                           # 1 3
        self.lambda_sim0    = 0.8                           # 0.2.  0.8 2
        # self.lambda_loss    = 0.2
        self.lambda_dist    = 0.05
        self.time_const     = 1.0 * self.epochs                           # 退火常数 200 0.5 0.7
        # -------- 阈值 + 时间窗 -------- HEDONIC★
        self.util_threshold = 0.0                      # 初始阈值
        self.target_good_ratio = 0.5                   # 期望 good_set ≈ 30% of outs 0.5(0706)
        self.tolerance_ratio   = 0.05                  # 可接受波动 ±5%
        self.adjust_step       = 0.002                 # 每次阈值调整幅度 0.07
        self.time_window    = getattr(args, "time_window", 2*size)   # 至少每 50 轮被选一次 2/3 * size
        self.last_chosen_round = np.zeros(size, dtype=int)  
    compressor：
        COS_MIN = 0.984
        COS_MAX = 0.987
        EPS     = 1e-8                 # 防止除 0 / 负值

        # 原始 cosine（float）
        cos_raw = torch.dot(local_slice, neigh_slice) / (
                local_slice.norm() * neigh_slice.norm() + EPS)
        if cos_raw < self.min_sim:
            self.min_sim = cos_raw
        elif cos_raw > self.max_sim:
            self.max_sim = cos_raw
        logging.info("testing----------cos_raw: {:.6f}, min_sim: {:.6f}, max_sim: {:.6f}".format(
            cos_raw, self.min_sim, self.max_sim
        ))


        # ---------- 线性拉伸 ----------
        if cos_raw < COS_MIN:
            cos_raw = COS_MIN
        elif cos_raw > COS_MAX:
            cos_raw = COS_MAX
        cos_sim = (cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS)


-   FLOCK-0706-8-realpush-sum-randomk099-utileps03-ratio03-ph306（best acc1: 197,97.38,39.28025）和GossipFL的99.15差距太大了
当前参数如下：self.util_cache     = np.zeros(size)                # 邻居效用 EMA
        self.util_alpha     = 0.2                           # EMA 衰减 0.1
        self.util_eps       = 0.3                          # ε‑greedy 0.05(630-4)  0.1(0701-1) 0.5(0706)
        self.lambda_bw0     = 3.0                           # 1 3
        self.lambda_sim0    = 0.8                           # 0.2.  0.8 2
        # self.lambda_loss    = 0.2
        self.lambda_dist    = 0.05
        self.time_const     = 1.0 * self.epochs                           # 退火常数 200 0.5 0.7
        # -------- 阈值 + 时间窗 -------- HEDONIC★
        self.util_threshold = 0.0                      # 初始阈值
        self.target_good_ratio = 0.3                   # 期望 good_set ≈ 30% of outs 0.5(0706)
        self.tolerance_ratio   = 0.05                  # 可接受波动 ±5%
        self.adjust_step       = 0.002                 # 每次阈值调整幅度 0.07
        # self.time_window    = getattr(args, "time_window", 2*size)   # 至少每 50 轮被选一次 2/3 * size
        self.time_window = int(np.ceil(3 * np.log(size)))
        self.last_chosen_round = np.zeros(size, dtype=int)  
    compressor：
        COS_MIN = 0.95
        COS_MAX = 1
        EPS     = 1e-8                 # 防止除 0 / 负值

        # 原始 cosine（float）
        cos_raw = torch.dot(local_slice, neigh_slice) / (
                local_slice.norm() * neigh_slice.norm() + EPS)
        if cos_raw < self.min_sim:
            self.min_sim = cos_raw
        elif cos_raw > self.max_sim:
            self.max_sim = cos_raw
        logging.info("testing----------cos_raw: {:.6f}, min_sim: {:.6f}, max_sim: {:.6f}".format(
            cos_raw, self.min_sim, self.max_sim
        ))


        # ---------- 线性拉伸 ----------
        if cos_raw < COS_MIN:
            cos_raw = COS_MIN
        elif cos_raw > COS_MAX:
            cos_raw = COS_MAX
        cos_sim = (cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS)

（5）我认为可能的优化点：
-   首先，由于是极端的non-iid，可能goodset ratio可以进一步缩小
-   其次，是否尽早引入节点相似性，在non-iid里，接收到不相似邻居的param反而会降低acc
-   合理调整choose neighbor


(6) 我通过uncompress重写验证了压缩与解压缩的正确性。那么就需要考虑，如果是randomk的话，param的缩放问题。
-   如果是0.99压缩率，缩放就是1/0.99，聚合后还需要再乘以0.99

## !!!!!目前已经成功打败GossipFL，一定记住，在/home/dddddddd/XXXXX/GossipFL/compression/compressors_simple.py中，用GossipFL的代码
-   最终代码文件：
-   -   decentralized_worker_manager_FLOCK_999_最终版.py
-   -   

可以直接使用这个文件作为最终结果：
-   MNIST/1FINAL/FLOCK-0706-9-test-realpush-sum-randomk099-utileps03-ratio03-ph306.log
-   MNIST/1FINAL/DPSGD-0707-1-labe12.log              (0707添加)
-   MNIST/1FINAL/CHOCOSGD-0707-1-labe12.log           （0707添加，修改了GossipFL/compression/compressors_simple.py中的topk，返回真实的topk）


（1）接下来需要做的是训练一个cifar10的。然后跑几个对照试验。不微调了。

echo "./launch_mpi_based.sh > CIFAR10/FLOCK-0706-1.log 2>&1 & disown"   | at now + 2 hours

## 2025-07-07 
今天早上起来看CIFAR10/FLOCK-0706-1.log 2>&1，结果是，最高的acc1只有   298,36.50841346153846,40.8979。。。这不太正常，首先尝试着训练一下GossipFL试试。
（1）GossipFL的CIFAR10:GossipFL-0707-1.log
(2)今天的第二个任务是，跑完DPSGD和CHOCO-SGD的任务，
-   需要调节其中的compress——method都是topk，不知道会不会有影响


可以直接使用这个文件作为最终结果：
-   MNIST/1FINAL/FLOCK-0706-9-test-realpush-sum-randomk099-utileps03-ratio03-ph306.log （压缩率是0.99）
-   MNIST/1FINAL/DPSGD-0707-1-labe12.log              (0707添加)
-   MNIST/1FINAL/CHOCOSGD-0707-2-unbiased-labe12.log （0707添加，修改了GossipFL/compression/compressors_simple.py中的topk，返回真实的topk）
-   -   压缩率是0.01，仅保留0.01的参数
-   -   由于其带有误差补偿
-   MNIST/1FINAL/GossipFL-0705-1-099-label2.log  （压缩率是0.99）


echo "./launch_mpi_based.sh > CIFAR10/RESNET20/FLOCK-0709-1-cr1-labe12.log 2>&1 & disown"   | at now + 1 hours
echo "./launch_mpi_based.sh > CIFAR10/RESNET20/FLOCK-0709-2-cr1-labe12.log 2>&1 & disown"   | at now + 2 hours
echo "./launch_mpi_based.sh > CIFAR10/RESNET20/FLOCK-0709-3-cr1-labe12.log 2>&1 & disown"   | at now + 3 hours
echo "./launch_mpi_based.sh > CIFAR10/RESNET20/FLOCK-0709-4-cr1-labe12.log 2>&1 & disown"   | at now + 4 hours
echo "algorithm=CHOCO_SGD ./launch_mpi_based.sh > CIFAR10/RESNET20/CHOCOSGD-0709-1-cr099-labe12.log 2>&1 & disown"   | at now + 5 hours
echo "algorithm=DPSGD ./launch_mpi_based.sh > CIFAR10/RESNET20/DPSGD-0709-1-labe12.log 2>&1 & disown"   | at now + 10 hours




## communication overhead

MNIST-CNN 0.00  单个 106455680 bit=12.69 MB
DPSGD 81651506560 /epoch = 9733.61808777MB * 92 epoch = 895492.86
CHOCO-SGD  12561770240 /epoch 
GOSSIPFL 6280885120 /epoch = 748.73985291MB * 15 epoch = 11231.09779358
FLOCK   6280885120 /epoch = 748.73985291MB * 10 epoch = 7487.3985291


CIFAR10-RESNET20  单个 17262208 bit=2.05781555 MB
DPSGD 13240113536 /epoch = 1578.3445282MB * 26 epoch = 41036.95773315
CHOCO-SGD  2036940544 /epoch = 242.82223511 * 50 epoch = 12141.11175537
GOSSIPFL 1018470272 /epoch = 121.41111755MB * 283 epoch = 34359.3462677
FLOCK   1018470272 /epoch = 121.41111755MB * 9 epoch = 1092.70005795




