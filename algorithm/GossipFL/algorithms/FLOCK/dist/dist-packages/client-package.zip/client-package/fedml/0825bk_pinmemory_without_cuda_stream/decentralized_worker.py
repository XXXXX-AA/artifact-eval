import logging
import time
from copy import deepcopy
import torch
from torch import nn
import traceback
from mpi4py import MPI
import threading

from utils.timer import Timer
# from fedml_api.utils.timer_with_cuda import Timer
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from algorithms.baseDecent.decentralized_worker import BaseDecentralizedWorker

class DecentralizedWorker(BaseDecentralizedWorker):
    def __init__(self, worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics):
        """
            The `compression` method should be specified in `args`.
        """
        self.worker_index = worker_index
        self.topology_manager = topology_manager
        self.refresh_gossip_info()
        #===========================================================================
        super().__init__(worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics)

        # =================================================
        # Specilaized for SAPS_FL
        # ============================================================
        self.param_groups = self.model_trainer.param_groups
        self.param_names = self.model_trainer.param_names

        self._shapes, self._total_len = self.init_flatten_params_shapes()


        # CPU 双缓冲
        self._rx_lock = threading.Lock()
        # 初始化 CPU 双缓冲（pinned）
        _cpu_buf = torch.zeros(self._total_len, dtype=torch.float32, device="cpu")
        self._rx_buf_a = _cpu_buf.pin_memory() if torch.cuda.is_available() else _cpu_buf
        self._rx_buf_b = torch.zeros_like(self._rx_buf_a)
        # self._rx_buf_a = torch.zeros(self._total_len, dtype=torch.float32, device="cpu").pin_memory()
        # self._rx_buf_b = torch.zeros_like(self._rx_buf_a).pin_memory()
        self._rx_active = self._rx_buf_a
        self._rx_standby = self._rx_buf_b

        # === H2D 重叠：独立复制流 + 可重用 GPU 侧 staging buffer + 事件 ===
        self._use_cuda = torch.cuda.is_available() and ("cuda" in str(self.device))
        self._copy_stream = torch.cuda.Stream(device=self.device) if self._use_cuda else None
        self._h2d_buf = None                # GPU 端临时缓冲，按需懒分配并复用
        self._h2d_event = torch.cuda.Event() if self._use_cuda else None


        # 训练步后记录的扁平参数快照（CPU）：由 manager 在 run_sync 内赋值
        self.step_param_cpu = None

        # 压缩器 & 即时评估回调（由 manager 注入）
        self._rx_comp = None
        self._eval_cb = None

        self.number_of_neighbor_param_received = 0
        self.neighbor_weight = 0.5
        self.total_neighbor_weight = 0.0
        self.is_last_step = False  # 是否为最后一个训练步

        # 统计计数器
        self.stat_rx_msgs = 0
        self.stat_batch_swaps = 0
        self.stat_batch_merge_h2d_time = 0.0
        self.stat_sim_computed = 0  # 已计算的相似度条数

    def set_rx_compressor(self, compressor):
        """由 manager 调用，把 compressor 注入到 worker（用于本地前移解压）。"""
        self._rx_comp = compressor

    def set_eval_callback(self, cb):
        """
        由 manager 注入回调，用于在接收线程里即时完成：
          - 对称 staleness 衰减
          - self._update_neighbor_utility(...)
        cb: Callable(neighbor_idx: int, sender_round: int, cos_sim: float) -> None
        """
        self._eval_cb = cb


    # ==============================================================================
    # Specilaized for SAPS_FL

    # file input implementation        
    def add_result_for_flock(self, worker_index, sender_round, updated_information):
        with torch.no_grad():  # ← 新增，确保不跟踪计算图
            logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
                self.worker_index, worker_index, sender_round))

            if self._rx_comp is None:
                raise RuntimeError("RX compressor not set. Call set_rx_compressor() in manager before training.")

            # —— 解压到 CPU（门面 API）——
            q_values = q_indices = idx = local_slice = neigh_slice = inc = None
            try:
                # (1) uncompress
                q_values, q_indices = self._rx_comp.decode_sparse_msg(updated_information, self._shapes)
                idx = q_indices.to(dtype=torch.long)  # 索引保证 
            
                # (2) calculate sim
                if self.step_param_cpu is not None:
                    local_slice = self.step_param_cpu[idx]
                    neigh_slice = q_values.to(local_slice.dtype)
                    EPS = 1e-8
                    denom = local_slice.norm() * neigh_slice.norm() + EPS
                    if float(denom) > 0.0:
                        cos_raw = torch.dot(local_slice, neigh_slice) / denom
                        COS_MIN, COS_MAX = 0.9, 1.0
                        cos_raw = torch.clamp(cos_raw, min=COS_MIN, max=COS_MAX)
                        cos_sim = float((cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS))
                else:
                    cos_sim = 1.0
                self.stat_sim_computed += 1    
                # (3) update staleness + utility
                if callable(self._eval_cb):
                    try:
                        self._eval_cb(int(worker_index), int(sender_round), float(cos_sim))
                    except Exception:
                        logging.exception("eval callback failed in add_result_for_flock")

                # (4) sum on CPU（w =  0.5）
                inc = (self.neighbor_weight * q_values).to(self._rx_active.dtype)
                with self._rx_lock:
                    self._rx_active.index_add_(0, idx, inc)
                    self.number_of_neighbor_param_received += 1
                    self.stat_rx_msgs += 1
                    self.total_neighbor_weight += self.neighbor_weight

            finally:
                # —— 及时释放局部张量引用，降低 RSS 峰值 —— 
                # 这些 del 只删除 Python 引用；真实内存释放取决于是否还有别的引用
                try: del idx
                except NameError: pass
                try: del inc
                except NameError: pass
                try: del local_slice
                except NameError: pass
                try: del neigh_slice
                except NameError: pass
                try: del q_values
                except NameError: pass
                try: del q_indices
                except NameError: pass
        



    # file output implementation
    def aggregate_for_flock(self, compressor, selected_shapes,flatten_params):
        # start_time = time.time()
        if self.number_of_neighbor_param_received == 0:
            return
        
        ready = None
        add_vec = None
        try:
            with self._rx_lock:
                ready = self._rx_active
                self._rx_active, self._rx_standby = self._rx_standby, self._rx_active
                self._rx_active.zero_()
                self.number_of_neighbor_param_received = 0
                self.total_neighbor_weight = 0.0
                

            # # 合并（H2D + add_）
            # t0 = time.time()
            # gpu_buf = flatten_params.buffer
            # add_vec = ready.to(device=gpu_buf.device, dtype=gpu_buf.dtype, non_blocking=True)
            # gpu_buf.add_(add_vec)
            # h2d_t = time.time() - t0

            # 合并（H2D + add_），使用 pinned+non_blocking + 独立 CUDA 流
            t0 = time.time()
            gpu_buf = flatten_params.buffer

            # CPU-only 路径（例如在 CPU 训练或无 CUDA 时）
            if (not self._use_cuda) or (not gpu_buf.is_cuda):
                add_vec_cpu = ready.to(dtype=gpu_buf.dtype, copy=False)
                gpu_buf.add_(add_vec_cpu)
                h2d_t = time.time() - t0
            else:
                # 1) 懒分配并复用 GPU staging 缓冲，避免频繁分配
                if (self._h2d_buf is None or
                    self._h2d_buf.dtype != gpu_buf.dtype or
                    self._h2d_buf.numel() != gpu_buf.numel() or
                    self._h2d_buf.device != gpu_buf.device):
                    self._h2d_buf = torch.empty_like(gpu_buf)

                # 2) 在独立复制流上发起 H2D：从 pinned CPU -> GPU
                #    注意：源 ready 必须为 pinned（上文 __init__ 已 pin_memory()）
                with torch.cuda.stream(self._copy_stream):
                    # 拷贝仅在 dtype 匹配时真正 zero-copy DMA；若 dtype 不同，请统一模型与缓冲 dtype
                    self._h2d_buf.copy_(ready.view_as(self._h2d_buf), non_blocking=True)
                    self._h2d_event.record(self._copy_stream)

                # 3) 让默认流等待复制完成，再执行就地加和
                torch.cuda.current_stream().wait_event(self._h2d_event)
                gpu_buf.add_(self._h2d_buf)
                h2d_t = time.time() - t0

            # 统计
            self.stat_batch_swaps += 1
            self.stat_batch_merge_h2d_time += float(h2d_t)

            # 清空 ready 内容，避免旧数据叠加
            ready.zero_()
        finally:
            # —— 释放局部引用 —— 
            try: del add_vec
            except NameError: pass
            try: del ready
            except NameError: pass




    def init_flatten_params_shapes(self):
        params, _shapes = get_data(self.param_groups, self.param_names, is_get_grad=False)
        _total_len = int(sum(p.numel() for p in params))
        return _shapes, _total_len


    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]
        self.in_neighbor_idx_list = self.topology_manager.get_in_neighbor_idx_list(self.worker_index)









