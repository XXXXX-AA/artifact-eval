import logging
import threading
import time
from copy import deepcopy
import torch, gc, os, psutil
proc = psutil.Process(os.getpid())
def mem_mb():
    rss = proc.memory_info().rss / (1024*1024)
    cuda = torch.cuda.memory_allocated() / (1024*1024) if torch.cuda.is_available() else 0
    return rss, cuda

def cpu_mem_str(tag=""):
    try:
        cpu = proc.cpu_percent(interval=None)  # 调用前先在 run() 开始处“预热”一次
    except Exception:
        cpu = -1.0
    rss, cuda = mem_mb()
    return f"{tag} CPU={cpu:.1f}% RSS={rss:.1f}MB CUDA={cuda:.1f}MB"

import traceback
from mpi4py import MPI
import numpy as np

from fedml_core.distributed.client.client_manager import ClientManager
from fedml_core.distributed.communication.message import Message

from algorithms.baseDecent.decentralized_worker_manager_FLOCK import BaseDecentralizedWorkerManager

from utils.context import (
    raise_MPI_error,
    raise_error_without_process,
    get_lock,
)
from utils.timer import Timer
from utils.tracker import RuntimeTracker
# from fedml_api.utils.timer_with_cuda import Timer
from utils.metrics import Metrics
from utils.wandb_util import wandb_log
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from .compressor import SAPS_FLCompressor
from .utils import generate_bandwidth

# from .SAPS_topology_manager import SAPSTopologyManager
from .message_define import MyMessage

from queue import Queue, Empty, Full

from algorithms.SAPS_FL.coalition_manager import CoalitionManager

comm = MPI.COMM_WORLD

class DecentralizedWorkerManager(BaseDecentralizedWorkerManager):
    def __init__(self, args, comm, rank, size, worker, topology_manager, model_trainer, timer, metrics):
        super().__init__(args, comm, rank, size, worker, topology_manager, model_trainer, timer, metrics)
        self.neighbor_transfer_lock = threading.Lock()
        self.sync_receive_all_event = threading.Event()
        self.complete_aggregation_event = threading.Event()

        # --- 新增：消息入队 + 异步落盘线程（不阻塞训练） ---
        self._rx_queue: Queue = Queue(maxsize=50)
        self._rx_stop = threading.Event()
        self._rx_thread = threading.Thread(
            name=f"rx-io-{rank}", target=self._rx_loop, daemon=True
        )
        # 训练单独线程
        self.training_thread = threading.Thread(
            name="training", target=self.run_sync, daemon=True
        )

        # whether all workers finished
        self.ifStop = False
        self.round = 0  # Current round index

        
        # compression part
        self.compression = args.compression
        assert self.compression in ["topk", "randomk", "quantize", "sign"]
        self.compressor = SAPS_FLCompressor(comm_op=self.compression,
                                            compress_ratio=args.compress_ratio,  # args.compress_ratio
                                            quantize_level=args.quantize_level,
                                            is_biased=(args.is_biased == 1),)

        # 注入：压缩器与即时评估回调
        self.worker.set_rx_compressor(self.compressor)
        self.worker.set_eval_callback(self._on_neighbor_eval)
        self.finish_round = self.epochs * self.worker.num_iterations-1


        # ---- HEDONIC 参数 ----
        self.bandwidth = generate_bandwidth(args)      # 0‑1 归一化带宽矩阵
        # if self.worker_index == 0:
        # logging.info(f"[rank {self.worker_index}] Bandwidth matrix:\n{self.bandwidth}")
        bw_raw = self.bandwidth[self.worker_index]     # 1-D
        bw_log_max = np.log1p(bw_raw).max() or 1.0     # 防除 0
        self.bw_norm = np.log1p(bw_raw) / bw_log_max   # 0-1
        self.outs = self.my_get_out_neighbor_idx_list(self.worker_index)
        self.coalition_manager = CoalitionManager(args, self.worker_index, size, self.bandwidth,self.bw_norm, self.outs)

    def run(self):
        logging.debug("Wait for the barrier!")
        comm.Barrier()
        time.sleep(1)
        logging.debug("MPI exit barrier!")

        proc.cpu_percent(interval=None)

        self._rx_thread.start()
        self.training_thread.start()

        if self.worker_index == 0:
            logging.debug("COORDINATOR notify clients to start!")
            self.coodinator_thread.start()
            self.notify_clients()
        super().run()

    def register_message_receive_handlers(self):
        # # 注册接收 Cluster Info
        # self.register_message_receive_handler(MyMessage.MSG_TYPE_CLUSTER_INFO,
        #                                       self.handle_msg_cluster_info)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR,
                                              self.handle_msg_from_neighbor)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_CLIENT_TO_COORDINATOR,
                                              self.handle_msg_client_to_coordinator)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_COORDINATOR_TO_CLIENT,
                                              self.handle_msg_coordinator_to_client)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_COAL_INFO,
                                              self.handle_msg_coalition_info)
        self.register_message_receive_handler(MyMessage.MSG_TYPE_COALITION_JOIN_NOTIFICATION,
                                              self.handle_msg_coalition_join)

    def handle_msg_client_to_coordinator(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        logging.debug("handle_msg_client_to_coordinator.  Sender_id = " + str(sender_id)+" Finished training.")

        with get_lock(self.total_metric_lock):
            logging.debug("get metric lock, handle_msg_client_to_coordinator. sender_id = " + str(sender_id)+" Finished training.")
            self.flag_client_finish_dict[sender_id] = True
            self.check_worker_finish_and_notify()

    def handle_msg_coordinator_to_client(self, msg_params):
        sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
        logging.debug("handle_msg_coordinator_to_client. Sender_id = " + str(sender_id)+" Finished training.")      

    def handle_msg_from_neighbor(self, msg_params):
       """改为入队，真正的落盘交给 _rx_loop；避免阻塞训练线程。"""
       try:
        #    self._rx_queue.put_nowait(msg_params)
        self._rx_queue.put(msg_params, block=True, timeout=0.5)
       except Full:
           # 队列偶尔满：兜底同步执行，避免丢包（极少数情况）
           try:
               sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
               sender_round = msg_params.get(MyMessage.MSG_ARG_KEY_LOCAL_ROUND)
               logging.warning("rx queue full; process inline for sender=%s round=%s", sender_id, sender_round)
               with get_lock(self.neighbor_transfer_lock):
                   self.worker.add_result_for_flock(sender_id, sender_round, msg_params)
           except Exception:
               logging.exception("fallback add_result_for_flock failed")
       return                                    

    def handle_msg_coalition_info(self, msg):
        # handle coalition info and piggyback message with params 
        sender_id = msg.get(MyMessage.MSG_ARG_KEY_SENDER)
        self.coalition_info_and_pigiback_update(msg, sender_id)


    def handle_msg_coalition_join(self, msg):
        # handle coalition join notification
        sender_id = msg.get(MyMessage.MSG_ARG_KEY_SENDER)
        self.coalition_join_update(msg, sender_id)

        now = time.time()

        # case1: only coalition join notifacation
        if isinstance(msg, dict) and msg.get("msg_type") == "COALITION_JOIN_ACK":
            member = int(msg["member"])
            ci     = int(msg["ci"])
            ver    = int(msg["ver"])
            with self._coal_lock:
                # 去重：见过同一个 (member, ver) 就不再处理
                key = (member, ver)
                if key in self._coal_seen_delta:
                    return
                self._coal_seen_delta.add(key)

                # 只要 ver 变大，就覆盖邻居缓存（我们无需维护全量 coalition_set）
                old = self._neighbor_coal_cache.get(member)
                if (old is None) or (ver > old[1]):
                    self._neighbor_coal_cache[member] = (ci, ver, now)

                # 将该增量再入队，等待后续 piggyback（形成懒传播）
                self._coal_delta_q.append((member, ci, ver, now))
            return

        # 情况2：piggyback 的 (member, ci, ver) 列表
        deltas = None
        if isinstance(msg, dict) and "coal_deltas" in msg:
            deltas = msg["coal_deltas"]
        elif hasattr(msg, "get") and msg.get("coal_deltas") is not None:
            deltas = msg.get("coal_deltas")

        if not deltas:
            return

        with self._coal_lock:
            for tup in deltas:
                try:
                    member, ci, ver = int(tup[0]), int(tup[1]), int(tup[2])
                except Exception:
                    continue

                key = (member, ver)
                if key in self._coal_seen_delta:
                    continue
                self._coal_seen_delta.add(key)

                old = self._neighbor_coal_cache.get(member)
                if (old is None) or (ver > old[1]):
                    self._neighbor_coal_cache[member] = (ci, ver, now)

                # 继续懒传播
                self._coal_delta_q.append((member, ci, ver, now))


    def run_sync(self):
        with raise_MPI_error():
            for epoch in range(self.epochs):
                if self.worker_index == 0:
                    rss, cuda = mem_mb()
                    logging.info(f"[rank {self.worker_index}] RSS={rss:.1f}MB CUDA={cuda:.1f}MB after dataloader ready")
                self.epoch = epoch
                n_bits = 0
                self.epoch_init()
                for iteration in range(self.worker.num_iterations):
                    if self.round >= self.finish_round:
                        self.worker.is_last_step = True
                    self.iteration = iteration

                    # Train first, and then transfer the model
                    if self.args.Failure_chance is not None and np.random.rand(1) < self.args.Failure_chance:
                        logging.info("Communication Failure happens on worker: {}, Failure_chance: {}".format(
                            self.worker_index, self.args.Failure_chance))
                    else:
                        logging.debug("Start training on worker: {}, Epoch: {}, Iteration: {}".format(
                            self.worker_index, self.epoch, self.iteration))
                        time_before_train = time.time()
                        self.lr_schedule(self.epoch, self.iteration, self.global_round_idx,
                                         self.worker.num_iterations, self.args.warmup_epochs)
                        # update x_half to x_{t+1} by SGD
                        loss, output, target = self.worker.train_one_step(
                            self.epoch, self.iteration, self.train_tracker, self.metrics
                        )
                        time_after_train = time.time()
                        if self.worker_index == 6 and self.iteration == 0:
                            logging.info("Worker %d, Epoch %d, Iteration %d, Train Time: %.2f" %
                                         (self.worker_index, self.epoch, self.iteration,
                                          time_after_train - time_before_train))

                    time_before_compress = time.time()
                    # Get model params
                    params, self.worker.shapes = get_data(
                        self.worker.param_groups, self.worker.param_names, is_get_grad=False
                    )
                    flatten_params = TensorBuffer(params)
                    # ----- for real push-sum -----
                    flatten_params.buffer.mul_(0.5)  # apply push-sum weight (halve local params)
                    # Update GPU and CPU param snapshots for cosine similarity
                    src = flatten_params.buffer
                    dst = self.worker.step_param_cpu
                    if self.worker._use_cuda and src.is_cuda:
                        # Store GPU param snapshot for cos sim (no copy, just reference)
                        self.worker.step_param_gpu = src.detach()
                    else:
                        if (dst is None) or (dst.numel() != src.numel()) or (dst.dtype != src.dtype):
                            self.worker.step_param_cpu = torch.empty_like(src, device='cpu', dtype=src.dtype)
                            # GPU -> CPU copy (non-blocking)
                            self.worker.step_param_cpu.copy_(src, non_blocking=True)

                    # compress
                    sync_buffer = {
                        "original_shapes": self.worker.shapes,
                        "flatten_params": flatten_params,
                    }
                    self.compressor.compress(sync_buffer)
                    self.selected_shapes = sync_buffer["selected_shapes"]

                    # Choose a neighbor to send (Hedonic gossip)
                    neighbor_idx = self.coalition_manager._choose_neighbor()
                    if self.compression in ["randomk", "topk"]:
                        n_bits += sync_buffer["n_bits"]
                        self.send_sparse_params_to_neighbors(
                            neighbor_idx, self.round,
                            sync_buffer["flatten_selected_values"].buffer.cpu(),
                            sync_buffer["flatten_selected_indices"].buffer.cpu(),
                            sync_buffer["selected_shapes"],
                            self.worker.get_dataset_len()
                        )
                    else:
                        raise NotImplementedError

                    time_after_compress = time.time()
                    if self.worker_index == 6 and self.iteration == 0:
                        logging.info("Worker %d, Epoch %d, Iteration %d, Compress Time: %.2f" %
                                     (self.worker_index, self.epoch, self.iteration,
                                      time_after_compress - time_before_compress))

                    
                    time_before = time.time()
                    total_neighbor_cnt = self.aggregate(flatten_params,sync_buffer)
                    time_after = time.time()
                    if self.worker_index == 6 and self.iteration == 0:
                        logging.info("Round %d, Iteration %d, while_cnt: %.2f, Time: %.2f" %
                                     (self.round, self.iteration, total_neighbor_cnt, time_after - time_before))
                    # Write back updated params to model
                    sync_buffer["flatten_params"].unpack(params)

                    # Cleanup large temporary buffers
                    try:
                        del sync_buffer["flatten_selected_values"]
                        del sync_buffer["flatten_selected_indices"]
                    except KeyError:
                        pass
                    try:
                        del flatten_params
                    except Exception:
                        pass

                    self.round += 1

                    if (self.iteration % 50) == 0:
                        gc.collect()
                # End of iteration loop

                time_before_test = time.time()
                self.test_and_log(iteration, epoch)
                time_after_test = time.time()
                if self.worker_index == 6:
                    logging.info("Worker %d, Epoch %d, Iteration %d, Test Time: %.2f" %
                                 (self.worker_index, self.epoch, self.iteration,
                                  time_after_test - time_before_test))
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            # End of epoch loop

            self.send_notify_to_coordinator(0)


    def aggregate(self,flatten_params,sync_buffer):
        total_neighbor_cnt = 0
        has_payload = self.worker.has_payload_for_merge()
        if not has_payload:
            flatten_params.buffer.div_(0.5)
        else:
            if self.worker.is_last_step == False: 
                total_neighbor_cnt += self.worker.number_of_neighbor_param_received
                self.worker.aggregate_for_flock(self.compressor, sync_buffer["original_shapes"], sync_buffer)
            else:
                while self.worker.has_payload_for_merge():
                    total_neighbor_cnt += self.worker.number_of_neighbor_param_received
                    self.worker.aggregate_for_flock(self.compressor, sync_buffer["original_shapes"], sync_buffer)
                    flatten_params.buffer.mul_(0.5)
                flatten_params.buffer.div_(0.5)
        return total_neighbor_cnt
    
    
    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]

    def send_result_to_neighbors(self, receive_id, client_params1, local_sample_number):
        logging.debug("send_result_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_PARAMS_1, client_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)

    def send_sparse_params_to_neighbors(self, receive_id, round, client_sparse_params1, client_sparse_index1, selected_shapes, local_sample_number):
        logging.debug("send_sparse_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_SPARSE_PARAMS_1, client_sparse_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1, client_sparse_index1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        message.add_params(MyMessage.MSG_ARG_KEY_LOCAL_ROUND, round)
        message.add_params(MyMessage.MSG_ARG_KEY_SELECTED_SHAPES, selected_shapes)
        self.send_message(message)


    # param send for lazy gossip coalition pigiback
    def send_sparse_params_with_coalition_to_neighbors(self, receive_id, client_sparse_params1, client_sparse_index1, selected_shapes, local_sample_number):
        logging.debug("send_sparse_params_with_coalition_to_neighbors. receive_id = " + str(receive_id))

        # 1. send sparse params
        message1 = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message1.add_params(MyMessage.MSG_ARG_KEY_SPARSE_PARAMS_1, client_sparse_params1)
        message1.add_params(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1, client_sparse_index1)
        message1.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        message1.add_params(MyMessage.MSG_ARG_KEY_LOCAL_ROUND, round)
        message1.add_params(MyMessage.MSG_ARG_KEY_SELECTED_SHAPES, selected_shapes)

        # 2. send coalition and deltas
        message2 = Message(MyMessage.MSG_TYPE_COAL_INFO, self.get_sender_id(), receive_id)
        self.coalition_manager.add_self_coalition_info(message2)
        self.coalition_manager.add_coalition_deltas(message2)

        self.send_message(message1)
        self.send_message(message2)


    def send_quant_params_to_neighbors(self, receive_id, client_quant_params1, local_sample_number):
        logging.debug("send_quant_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_QUANT_PARAMS_1, client_quant_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)

    def send_sign_params_to_neighbors(self, receive_id, client_sign_params1, local_sample_number):
        logging.debug("send_sign_params_to_neighbors. receive_id = " + str(receive_id))
        message = Message(MyMessage.MSG_TYPE_SEND_MSG_TO_NEIGHBOR, self.get_sender_id(), receive_id)
        message.add_params(MyMessage.MSG_ARG_KEY_SIGN_PARAMS_1, client_sign_params1)
        message.add_params(MyMessage.MSG_ARG_KEY_NUM_SAMPLES, local_sample_number)
        self.send_message(message)
    
    def send_notify_to_coordinator(self, receive_id=0):
        logging.debug("send_notify_to_coordinator. receive_id = %s, round: %s" %
                      (str(receive_id), str(self.round)))
        message = Message(MyMessage.MSG_TYPE_CLIENT_TO_COORDINATOR, self.get_sender_id(), receive_id)
        self.send_message(message)

    def check_whether_all_clients_finish_receive(self):
        for rank, flag in self.flag_client_finish_dict.items():
            if not flag:
                return False
        return True

    def check_worker_finish_and_notify(self):
        if self.check_whether_all_clients_finish_receive():
            logging.debug(">>>>>>>>>>>>>>>COORDINATOR Receive all, ROUND %d finished!<<<<<<<<" %
                          (self.round))
            self.finish()

    

    def my_get_out_neighbor_idx_list(self, worker_idx: int):
        """
        返回指定节点可发送的邻居列表。
        规则：同一行带宽 > 0 且非对角元素即为出边。
        若带宽矩阵已归一化，0 表示不可达。
        """
        assert hasattr(self, "bandwidth"), "请先生成并归一化 self.bandwidth"
        row = self.bandwidth[worker_idx]
        # 取带宽正值且列索引 ≠ 自己
        outs = [j for j, bw in enumerate(row) if (j != worker_idx) and (bw > 0)]
        return outs

    def _on_neighbor_eval(self, neighbor_idx: int, sender_round: int, cos_sim: float):
        """Callback for neighbor evaluation (staleness can be derived if needed)."""
        try:
            staleness = max(0, self.round - sender_round)
        except:
            staleness = 0
        self.coalition_manager._update_neighbor_utility(neighbor_idx, cos_sim, staleness,self.round,self.epoch,self.worker.num_iterations)

    def _rx_loop(self):
        counter = 0
        while not self._rx_stop.is_set():
            try:
                msg_params = self._rx_queue.get(timeout=0.2)
            except Empty:
                continue
            try:
                sender_id = msg_params.get(MyMessage.MSG_ARG_KEY_SENDER)
                sender_round = msg_params.get(MyMessage.MSG_ARG_KEY_LOCAL_ROUND)

                # 处理 piggyback 的 coalition 信息
                self.coalition_pigiback_update(msg_params,sender_id)

                # 与原来保持一致：落盘在 worker.add_result_for_flock 中完成
                with get_lock(self.neighbor_transfer_lock):
                    self.worker.add_result_for_flock(sender_id, sender_round, msg_params)
                counter += 1
                # if (counter % 200) == 0:
                #     logging.info(cpu_mem_str(f"[rx] q={self._rx_queue.qsize()}"))
            except Exception:
                logging.exception("rx-io thread failed to add_result_for_flock")
            finally:
                    # try:
                    #     if isinstance(msg_params, dict):
                    #         msg_params.clear()  # 释放其中的 tensor 引用
                    # except Exception:
                    #     pass
                    self._rx_queue.task_done()



        


