# 搭建环境
## 安装docker
    sudo apt-get update && sudo apt-get install docker.io docker-compose
    sudo systemctl enable docker && sudo systemctl start docker
    # 验证安装
    docker --version  # 输出 Docker 版本
    docker-compose --version
    # 创建并激活虚拟环境（任选一种方式）
    # 创建虚拟环境并继承主环境包
    python3 -m venv myenv --system-site-packages
    source myenv/bin/activate
## 安装FedML
    # 安装 FedML 等 Python 库（此时仅在虚拟环境中生效）
    pip install fedml
    pip install "fedml[gpu]"  # 若需GPU支持
## 将当前用户加入docker组（避免每次sudo）
    sudo usermod -aG docker $USER
    newgrp docker  # 刷新组权限
## 允许 Docker 容器间通信（需调整防火墙）
    sudo iptables -P FORWARD ACCEPT  # 允许容器间流量转发
## 修改docker国内镜像源
    # 创建或修改 Docker 配置
    sudo mkdir -p /etc/docker
    sudo tee /etc/docker/daemon.json <<-'EOF'
    {
    "registry-mirrors": [
        "https://registry.cn-hangzhou.aliyuncs.com",
        "https://docker.mirrors.ustc.edu.cn",
        "https://hub-mirror.c.163.com"
    ]
    }
    EOF

    # 重启 Docker 服务
    sudo systemctl daemon-reload
    sudo systemctl restart docker

# 安装fedml的docker镜像支持
## 尝试从阿里云镜像拉取（替换官方标签）
    docker pull registry.cn-hangzhou.aliyuncs.com/fedml/fedml:latest-torch2.1.0-cuda11.8
    # 这里发现并没有合适的FedML docker镜像文件可以使用，因此需要自己构建一个离线的docker镜像


    # 在宿主机上先把所有要安装的包都 pip download 下来：
    mkdir -p ~/wheels
    pip download \
    --index-url https://download.pytorch.org/whl/cu124 \
    --extra-index-url https://pypi.org/simple \
    torch==2.4.1+cu124 \
    torchvision==0.19.1+cu124 \
    torchaudio==2.4.1+cu124 \
    -d ~/wheels

    # 再下载 FedML 本身
    pip download fedml -d ~/wheels


    # 新建目录 docker-fedml/，在里面放一个 Dockerfile
    # Dockerfile文件内容：
        FROM nvidia/cuda:12.4.1-cudnn-runtime-ubuntu22.04


        # 安装 Python3 & pip
        RUN apt-get update && \
            apt-get install -y --no-install-recommends python3 python3-pip && \
            rm -rf /var/lib/apt/lists/*

        # ←—— 下面这两行就在 Dockerfile 里 ——→
        COPY wheels/ /opt/wheels/
        RUN pip3 install --no-cache-dir /opt/wheels/*.whl

        WORKDIR /workspace

    # 1. 进入 docker-fedml 的目录
    cd /home/dddddddd/XXXXX/FLOCK/docker-fedml

    # 2. 创建 wheels 子目录（如果还没创建过）
    mkdir -p wheels

    # 3. 把你之前下载好的 .whl 文件全都拷进来
    cp /home/dddddddd/wheels/*.whl wheels/

    # 确认一下结构，大概是这样：
    # /home/dddddddd/XXXXX/FLOCK/docker-fedml/
    # ├─ Dockerfile
    # └─ wheels/
    #    ├─ torch-2.4.1+cu124-...whl
    #    ├─ torchvision-0.19.1+cu124-...whl
    #    ├─ torchaudio-2.4.1+cu124-...whl
    #    └─ fedml-*.whl
    #
    # Dockerfile 里就可以安全地写：
    # COPY wheels/ /opt/wheels/
    # RUN pip3 install --no-cache-dir /opt/wheels/*.whl

    # 4. 在 docker-fedml 目录下构建镜像
    docker build -t myfedml:2.4.1-cuda12.4 .

### 在此期间遇到的一些包的版本问题：
    （1）networkx
    dddddddd@dddddddd:~/XXXXX/FLOCK/docker-fedml$ unzip -p wheels/fedml-0.9.6-py2.py3-none-any.whl \
    fedml-0.9.6.dist-info/METADATA \
    | grep -i "Requires-Dist: networkx"
    Requires-Dist: networkx<3.0
    
    cd /home/dddddddd/XXXXX/FLOCK/docker-fedml/wheels
    # 删除所有 >=3.0 的 networkx 轮子
    rm networkx-3.*.whl

    （2）numpy
       
    dddddddd@dddddddd:~/XXXXX/FLOCK/docker-fedml$ unzip -p wheels/fedml-0.9.6-py2.py3-none-any.whl \
    fedml-0.9.6.dist-info/METADATA \
    | grep -i "Requires-Dist: numpy"
    Requires-Dist: numpy<2.0.0

    cd /home/dddddddd/XXXXX/FLOCK/docker-fedml/wheels
    rm numpy-2.2.6*.whl


    （3）多个cuda
     # 进入 wheels 目录
    cd /home/dddddddd/XXXXX/FLOCK/docker-fedml/wheels

    # 删除不需要的 12.6.x 版
    rm nvidia_cublas_cu12-12.6.4.1*.whl
    rm nvidia_cuda_cupti_cu12-12.6.80*.whl
    rm nvidia_cuda_nvrtc_cu12-12.6*.whl
    rm nvidia_cuda_runtime_cu12-12.6*.whl
    rm nvidia_cudnn_cu12-9.5.1.17*.whl
    rm nvidia_cufft_cu12-11.3.0.4*.whl
    rm nvidia_curand_cu12-10.3.7.77*.whl
    rm nvidia_cusolver_cu12-11.7.1.2*.whl
    rm nvidia_cusparse_cu12-12.5.4.2*.whl
    rm nvidia_nccl_cu12-2.26.2*.whl
    rm nvidia_nvjitlink_cu12-12.6.85*.whl
    rm nvidia_nvtx_cu12-12.6.77*.whl

    (4)其他冲突
    rm torch-2.7.1*.whl
    rm torchvision-0.22.1*.whl
    rm triton-3.3.1*.whl

### 成功构造了自己的本地docker
    Successfully built a14dd36db150
    Successfully tagged myfedml:2.4.1-cuda12.4

    测试：
    docker run --rm -it --gpus all myfedml:2.4.1-cuda12.4 bash
    报错：
    docker: Error response from daemon: could not select device driver "" with capabilities: [[gpu]].
    原因：
    Docker 还没配置好 NVIDIA 容器运行时（Container Toolkit
#### 解决以上问题：
    (1) 设置包仓库
    distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
    curl -s -L https://nvidia.github.io/nvidia-docker/gpgkey | sudo apt-key add -
    curl -s -L https://nvidia.github.io/nvidia-docker/$distribution/nvidia-docker.list | \
    sudo tee /etc/apt/sources.list.d/nvidia-docker.list
    sudo apt-get update

    （2）安装 nvidia-docker2
    sudo apt-get install -y nvidia-docker2
    （3）重启docker守护进程并测试
    sudo systemctl restart docker
    docker run --rm --gpus all nvidia/cuda:12.4.1-cudnn-runtime-ubuntu22.04 nvidia-smi 
    
    (or)

    docker run --rm -it --gpus all myfedml:2.4.1-cuda12.4 bash

    (output:)

        ==========
        == CUDA ==
        ==========

        CUDA Version 12.4.1

# 至此，成功安装了fedml的docker镜像支持
## 镜像备份：
    docker save -o myfedml_mpi_backup_20250715.tar myfedml:mpi
## 镜像恢复/加载：
    docker load -i myfedml_mpi_backup_20250715.tar
### 测试代码：
    docker run --rm -it --gpus all myfedml:2.4.1-cuda12.4 bash #进入镜像内部bash
    python3 - <<'EOF'
    import torch, fedml
    print("torch:", torch.__version__, "cuda:", torch.version.cuda, "available:", torch.cuda.is_available())
    print("fedml:", fedml.__version__)
    EOF
    exit #关闭容器

# 测试分布式FL环境搭建
## 测试代码：
    docker run --rm -it --entrypoint bash myfedml:mpi

    docker-compose down
    docker-compose up -d --scale client=1
    docker-compose logs -f --tail=100


    docker-compose down
    docker-compose up -d
    docker-compose logs -f --tail=100
    
    docker-compose down
    docker-compose up -d
    docker-compose logs -f server

    local test:

    mpirun --allow-run-as-root -np 4 python3 launcher.py --worker_num 3 --client_num_per_round 1 --comm_round 10

    mpirun --allow-run-as-root -np 4 \
       python3 launcher.py \
       --worker_num 3 \
       --client_num_per_round 1 \
       --comm_round 10

# 最新镜像列表
    (1) myfedml:2.4.1-cuda12.4   ID: a14dd36db150
    (2) myfedml:mpi              ID: 76b14809c059
    (3) gossipfl:latest          ID: e1aa275d1fdb 7b928a90c1d2
# 直接在运行时挂在本地代码地址即可：
    docker run --gpus all --rm -it   -v /home/dddddddd/XXXXX:/workspace   -w /workspace/GossipFL/experiments/mpi_based   gossipfl:latest   bash launch_mpi_based_docker.sh > 1.log

    docker build -t gossipfl:latest .

    docker run --gpus all --rm -it \
  -v /home/dddddddd/XXXXX/GossipFL:/workspace/GossipFL \
  -v /home/dddddddd/XXXXX/GossipFL/data:/workspace/data \
  -w /workspace/GossipFL/experiments/mpi_based \
  gossipfl:latest \
  bash launch_mpi_based_docker.sh --data_dir /workspace/data > 1.log





    docker-compose down -v --remove-orphans
    docker-compose up -d --scale worker=14 launcher
    docker-compose logs -f launcher

(
  docker-compose down -v --remove-orphans &&
  docker-compose up -d --scale worker=14 launcher &&
  docker-compose logs -f launcher
) >20epo_noloss_0718.log 2>&1 & disown
    

while true; do
  docker stats --no-stream \
    --format '{{.Name}}\t{{.NetIO}}'
  sleep 10
done >> docker_net_stats.log


验证nvidia：
    python3 - <<'PY'
    import torch, os
    print("Torch CUDA available:", torch.cuda.is_available())
    print("Visible devices:", os.environ.get("CUDA_VISIBLE_DEVICES", "not set"))
    print("Current device:", torch.cuda.current_device() if torch.cuda.is_available() else "cpu")
    PY




docker run --gpus all --rm -it   gossipfl:latest   bash 



    docker-compose build --no-cache launcher   # 如果 launcher 有单独 build
    docker-compose down -v --remove-orphans
    docker-compose up -d
    docker-compose logs -f launcher

# 以下命令运行没问题，但是实施测试的带宽是有问题的。
    (
    docker-compose down -v --remove-orphans &&
    docker-compose up -d --scale worker=14 launcher &&
    docker-compose logs -f launcher
    ) >100epo_noloss_0718.log 2>&1 & disown


# 目前的进展，和TODO
## 目前的进展：
    （1）可以在一个docker中运行14个进程，类似于把本地的所有实验放在了一个容器中。
## TODO
    （1）原来运行的代码是./launch_mpi_based.sh
    （2）运行后会自动解析三个.conf文件，获取所有配置后，发送给main.py
    （3）我需要写一个脚本，自动基于launch_mpi_based.sh的内容，然后基于其内容解析三个.conf文件的内容，并逐一发送给main.py文件。同时，需要把API.py文件中的generate_topology逻辑放到docker-compose.yml文件中。
    （4）统一注册ssh，
    （5）直接使用containernet进行模拟

# 在docker的基础上，安装containernet
## Step 2: 安装Containernet依赖项
    sudo apt update
    sudo apt install -y ansible aptitude curl git build-essential python3 python3-pip python3-setuptools openvswitch-switch cgroup-tools

    # 手动安装 Mininet
    git clone https://github.com/mininet/mininet.git
    cd mininet
    sudo make install
    sudo python3 setup.py install


## Step 3: 克隆Containernet项目并安装
    git clone https://github.com/containernet/containernet.git
    cd containernet/ansible
    sudo ansible-playbook -i "localhost," -c local install.yml

    ‘以上不成功，因为安装的containernet默认安装的docker与已安装docker冲突’


    cd XXXXX/containernet
    sudo python3 -m pip install . --force-reinstall --no-build-isolation

    cd ~/fll_clean
    sudo python3 run_topo.py

    

    containernet> d2 bash
    iperf3 -s


    同时打开多个containernet CLI：
    sudo docker ps
    sudo docker exec -it mn.d1 bash
    iperf3 -c 10.0.0.252

    sudo systemctl restart docker
    sudo mn -c   /   or    /   docker ps -aq | xargs docker rm -f
    docker rm -f $(docker ps -aq --filter "name=mn.")
    docker ps -a | grep mn.worker && echo "请清理旧容器"
    sudo python3 run_containernet_topo.py

    sudo docker exec -it mn.worker0 bash
    docker logs mn.worker0


## 目前的状态
    （1）可以运行，但是无法通信
    因为之前基于MPI通信的只能是本机运行，我必须把它们迁移到基于PyTorch Distributed通信才可以。
    Bug：
    0 - 2025-07-21 09:53:01,722 data_loader.py[line:370] INFO client_index = 13, batch_num_train_local = 49, batch_num_test_local = 200
    0 - 2025-07-21 09:53:01,735 build.py[line:19] INFO create_model. model_name = mnistflnet, output_dim = 10
    0 - 2025-07-21 09:53:01,747 build.py[line:25] INFO MnistFLNet + MNIST or FMNIST
    0 - 2025-07-21 09:53:01,891 decentralized_worker.py[line:26] INFO [2]
    /workspace/GossipFL/model/cv/mnistflnet.py:19: UserWarning: Implicit dimension choice for softmax has been deprecated. Change the call to include dim=X as an argument.
    return F.softmax(x)
    Traceback (most recent call last):
    File "/workspace/GossipFL/fedml_core/distributed/communication/mpi/mpi_send_thread.py", line 27, in run
        self.comm.send(msg.to_string(), dest=dest_id)
    File "src/mpi4py/MPI.src/Comm.pyx", line 1962, in mpi4py.MPI.Comm.send
    File "src/mpi4py/MPI.src/msgpickle.pxi", line 243, in mpi4py.MPI.PyMPI_send
    mpi4py.MPI.Exception: MPI_ERR_RANK: invalid rank



# 0723- 代码已备份
## 目前的状态：1）可训练，2）可使用GPU，3）可以通信

    sudo docker system prune -f
    sudo mn -c

    sudo python3 launch_containernet_mpi.py > containernet.log 2>&1 & disown
    
    查看runtime
    docker inspect mn.worker0 | grep -i Runtime
    sudo dmesg | grep -i 'Killed process'
    

    进入容器
    sudo docker exec -it mn.worker0 bash    

    查看OOM
    sudo ./find_oom_workers.sh 

    # 宿主机实时看每容器内存
    watch -n 2 'docker stats --no-stream --format "table {{.Name}}\t{{.MemPerc}}\t{{.MemUsage}}"'


    检测容器内是否有GPU
    docker exec mn.worker0 python3 -c "import torch,platform;print(torch.version.cuda)"

    拷贝文件
    sudo docker cp mn.worker0:/workspace/mpi_train.log .

### 几个错误解决方法：
#### 容器中nvidia-smi失败时：
    (1)
    要首先要确定系统安装了nvidia-container-runtime，如果没有
    sudo apt update
    sudo apt install nvidia-container-runtime

    (2)
    /etc/docker/daemon.json中
    {
    "default-runtime": "nvidia",   
    "runtimes": {
        "nvidia": {
        "path": "nvidia-container-runtime",
        "runtimeArgs": []
        }
    }
    }

    <!-- (3) 修补node.py
        # ① 先取得正在被 Python 使用的 node.py 路径
        NODEPY=$(python3 - <<'PY'
        import mininet.node, pathlib
        print(pathlib.Path(mininet.node.__file__))
        PY)

        # ② 给 create_container(...) 增加 runtime 参数（只需执行一次）
        sudo sed -i '/host_config=hc,/a\        runtime=kwargs.get("runtime", "nvidia"),' "$NODEPY" -->
    （3）
    确保已安装官方 Container Toolkit
    把 Docker 默认运行时改成 nvidia
    sudo apt-get install -y nvidia-container-toolkit
    sudo nvidia-ctk runtime configure --runtime=docker


    （4）重启docker
    sudo systemctl restart docker
    dpkg -l | grep nvidia-container-runtime


# 0814 OOM partially solved
why and how：
-   Data loader loads all data on each node
-   -   solved by splitting data on rank 0 node, and saving to file, while other nodes load their slices
-   -   before: OOM within 10 epochs, after: OOM after 50 epochs
    
    
-   CPU memory block caused by neighbor message receiving and saving in buffer.
-   -   needs to solve this problem by splitting receiving and training into different threads.
-   -   coding..


# 0815 Trying to optimize codes to solve OOM
-   adding spill_queue.py, replacing **add_result_for_flock** and **aggregate_for_flock** from using buffer to file

# 0818 Separating training and receiving into different threads for non-blocking training
-   self._rx_queue: Queue = Queue(maxsize=4096)
        self._rx_stop = threading.Event()
        self._rx_thread = threading.Thread(
            name=f"rx-io-{rank}", target=self._rx_loop, daemon=True
        )
-   def _rx_loop(self):
-   def handle_msg_from_neighbor(self, msg_params):

# 0818 Adding an RAM cache budget to Quick store and process params from neighbors
-   Usage knobs (env vars):
-   SPILL_DIR                 : base dir for spill files (default: ./spill_queue/spill-rank{rank})
-   SPILL_RAM_MB              : RAM cache budget in MB (default: 128; 0 disables RAM cache)
-   SPILL_RAM_TTL             : seconds for lazy flush from RAM to disk (default: 0 = disabled)
-   SPILL_PREFETCH            : "1"/"0" enable/disable background prefetch (default: "1")
-   SPILL_PREFETCH_RESERVE    : fraction [0..1], min free ratio required to prefetch (default: 0.5)
-   SPILL_RAM_USE_FRAC_FOR_PUT: fraction [0..1], max ratio put() may occupy (default: 0.7)
-   SPILL_STATS_EVERY         : print stats every N ops (default: 0 = disabled)



# 0820 After using SPILL_PREFETCH, OOM came back.
## test_and_log blocks training and IO 
    add test_and_log to a thread


# 0825 real push-sum
    send 0.5*param, maintain 0.5*param
    receive, add, normalize, add to local test
    need local's sparse weight


# 0831 CPU-GPU parallization is memory consuming
    the solution is to add a rx_add stream on GPU, and perform sim calculation on GPU, thus we don't need to copy params_flattern each step to CPU

# 0901 2 GPU stream  losts of nan
    check param after local push-sum
    check param after aggregate_for_flock

# 0902 Local no problem, Top1 Acc 93.35
    ./clean.sh
    sudo python3 launch_containernet_mpi.py > containernet0904.log 2>&1 & disown
    
    查看runtime
    docker inspect mn.worker0 | grep -i Runtime
    sudo dmesg | grep -i 'Killed process'
    

    进入容器
    sudo docker exec -it mn.worker0 bash    

    查看OOM
    sudo ./find_oom_workers.sh 

    # 宿主机实时看每容器内存
    watch -n 2 'docker stats --no-stream --format "table {{.Name}}\t{{.MemPerc}}\t{{.MemUsage}}"'

# 0902 backup file in 0902_FLOCK_runable_par_on_GPU
    log file for 30 nodes test_memory_20250902_30node
## To do :
-   realize coalition synchronization based on gossip
-   add a new theory on tuning the hyperparameters of the system


# 0903 coalition and synchronization
## added all function of coalition to coalition_manager.py for better modularization.

# 0904 write coalition and synchronization functions into overleaf
-   all functions


# 0905 wsl test
    the home file in wsl is C:\Users\X\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc\LocalState in windows