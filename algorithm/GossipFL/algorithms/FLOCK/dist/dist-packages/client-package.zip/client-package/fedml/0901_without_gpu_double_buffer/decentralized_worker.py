import logging
import time
from copy import deepcopy
import torch
from torch import nn
import traceback
from mpi4py import MPI
import threading

from utils.timer import Timer
# from fedml_api.utils.timer_with_cuda import Timer
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from algorithms.baseDecent.decentralized_worker import BaseDecentralizedWorker

class DecentralizedWorker(BaseDecentralizedWorker):
    def __init__(self, worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics):
        """
            The `compression` method should be specified in `args`.
        """
        self.worker_index = worker_index
        self.topology_manager = topology_manager
        self.refresh_gossip_info()
        
        super().__init__(worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics)

        # =================================================
        # Specialized for SAPS_FL
        # ============================================================
        self.param_groups = self.model_trainer.param_groups
        self.param_names = self.model_trainer.param_names

        self._shapes, self._total_len = self.init_flatten_params_shapes()

        # CPU 双缓冲
        self._rx_lock = threading.Lock()
        # 初始化 CPU 双缓冲（pinned）
        _cpu_buf = torch.zeros(self._total_len, dtype=torch.float32, device="cpu")
        self._rx_buf_a = _cpu_buf.pin_memory() if torch.cuda.is_available() else _cpu_buf
        self._rx_buf_b = torch.zeros_like(self._rx_buf_a)
        self._rx_active = self._rx_buf_a
        self._rx_standby = self._rx_buf_b

        # ---- 邻居权重累加缓冲（与 _rx_* 一一对应）----
        _wcpu = torch.zeros(self._total_len, dtype=torch.float32, device="cpu")
        self._w_buf_a = _wcpu.pin_memory() if torch.cuda.is_available() else _wcpu
        self._w_buf_b = torch.zeros_like(self._w_buf_a)
        self.neighbor_total_weight_active = self._w_buf_a
        self.neighbor_total_weight_standby = self._w_buf_b

        # === H2D 重叠：独立复制流 + 可重用 GPU 侧 staging buffer + 事件 ===
        self._use_cuda = torch.cuda.is_available() and ("cuda" in str(self.device))
        self._copy_stream = torch.cuda.Stream(device=self.device) if self._use_cuda else None
        self._h2d_buf = None                # GPU 端临时缓冲，按需懒分配并复用
        self._h2d_event = torch.cuda.Event() if self._use_cuda else None
        # 若需要把“权重”也搬到 GPU 做归一化，可复用一块 staging
        self._h2d_wbuf = None

        # Two-phase nonblocking merge state
        self._merge_pending = False                        # there is an in-flight staged copy
        self._ready_inflight = None                        # CPU source waiting to be zeroed after apply
        self._wready_inflight = None

        # GPU asynchronous accumulation buffers and stream
        self._accum_stream = torch.cuda.Stream(device=self.device) if self._use_cuda else None
        self._gpu_buf_accum = None
        self._gpu_weight_accum = None
        
        self._gpu_buf_hot   = torch.zeros(self._total_len, dtype=torch.float32, device=self.device)
        self._gpu_w_hot     = torch.zeros_like(self._gpu_buf_hot)

        self._gpu_buf_ready = torch.zeros_like(self._gpu_buf_hot)
        self._gpu_w_ready   = torch.zeros_like(self._gpu_buf_hot)

        # Training step flattened param snapshot on GPU (after push-sum scaling)
        self.step_param_gpu = None

        # 训练步后记录的扁平参数快照（CPU）：由 manager 在 run_sync 内赋值
        self.step_param_cpu = None

        # 压缩器 & 即时评估回调（由 manager 注入）
        self._rx_comp = None
        self._eval_cb = None

        self.number_of_neighbor_param_received = 0
        self.neighbor_weight = 0.5
        self.total_neighbor_weight = 0.0
        self.is_last_step = False  # 是否为最后一个训练步

        # 统计计数器
        self.stat_rx_msgs = 0
        self.stat_batch_swaps = 0
        self.stat_batch_merge_h2d_time = 0.0
        self.stat_sim_computed = 0  # 已计算的相似度条数
        self.aggregate_cnt = 0

        self._accum_lock = threading.Lock()

    def set_rx_compressor(self, compressor):
        """由 manager 调用，把 compressor 注入到 worker（用于本地前移解压）。"""
        self._rx_comp = compressor

    def set_eval_callback(self, cb):
        """
        由 manager 注入回调，用于在接收线程里即时完成：
          - 对称 staleness 衰减
          - self._update_neighbor_utility(...)
        cb: Callable(neighbor_idx: int, sender_round: int, cos_sim: float) -> None
        """
        self._eval_cb = cb

    def add_result_for_flock(self, worker_index, sender_round, updated_information):
        """
        1) Decode to CPU (sparse indices/values)
        2) Compute cosine similarity against the latest local param snapshot
        3) Accumulate neighbor values into the active buffer (CPU or GPU) with push-sum weight
        4) Fire callback for staleness/utility update
        5) Push a flag for the manager/merger to stage
        """
        logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
            self.worker_index, worker_index, sender_round))
        with torch.no_grad():
            logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
                self.worker_index, worker_index, sender_round))

            if self._rx_comp is None:
                raise RuntimeError("RX compressor not set. Call set_rx_compressor() in manager before training.")

            # —— 解压到 CPU（门面 API）——
            q_values = q_indices = idx = None
            cos_sim = 0.0
            try:
                # (1) decode sparse message on CPU
                q_values, q_indices = self._rx_comp.decode_sparse_msg(updated_information, self._shapes)
                idx = q_indices.to(dtype=torch.long)
                # (2) calculate cosine similarity
                if self._use_cuda and (self.step_param_gpu is not None) and (self.step_param_gpu.numel() == self._total_len):
                    if sender_round == 0:
                        logging.info("Worker {} add_result_for_flock: using GPU path for accumulation.".format(self.worker_index))
                    # Move neighbor data to GPU
                    idx_gpu = idx.to(device=self.device, non_blocking=True)
                    q_values_gpu = q_values.to(device=self.device, dtype=torch.float32, non_blocking=True)
                    # Lazy allocate GPU accumulators
                    if (self._gpu_buf_accum is None or self._gpu_buf_accum.numel() != self._total_len 
                            or self._gpu_buf_accum.device != q_values_gpu.device):
                        logging.info("Worker {} add_result_for_flock: initial _gpu_buf_accum after receiving sender {} round {}".format(self.worker_index,worker_index,sender_round))
                        self._gpu_buf_accum = torch.zeros(self._total_len, dtype=q_values_gpu.dtype, device=q_values_gpu.device)
                        self._gpu_weight_accum = torch.zeros_like(self._gpu_buf_accum)
                    # Compute cosine similarity and accumulate contributions on a separate CUDA stream
                    cos_sim_tensor = torch.zeros(1, device=q_values_gpu.device, dtype=torch.float32)
                    with torch.cuda.stream(self._accum_stream):
                        # gather local slice from GPU snapshot and compute cosine similarity
                        local_slice_gpu = self.step_param_gpu[idx_gpu]
                        neigh_slice_gpu = q_values_gpu.to(dtype=local_slice_gpu.dtype)
                        EPS = 1e-8
                        denom = local_slice_gpu.norm() * neigh_slice_gpu.norm() + EPS
                        if float(denom) > 0.0:
                            cos_raw = torch.dot(local_slice_gpu, neigh_slice_gpu) / denom
                            cos_raw = torch.clamp(cos_raw, min=0.9, max=1.0)
                            cos_sim_tensor[0] = (cos_raw - 0.9) / (1.0 - 0.9 + EPS)
                        # Reset accumulators if this is the first neighbor message in the current step
                        with self._accum_lock:
                            if self.number_of_neighbor_param_received == 0:
                                self._gpu_buf_accum.zero_()
                                self._gpu_weight_accum.zero_()
                            # (3) accumulate neighbor's sparse values and weights on GPU
                            self._gpu_buf_accum.index_add_(0, idx_gpu, q_values_gpu)
                            self._gpu_weight_accum.index_add_(0, idx_gpu, torch.full_like(q_values_gpu, float(self.neighbor_weight)))
                    # Synchronize the accumulation stream and retrieve cosine similarity
                    self._accum_stream.synchronize()
                    cos_sim = float(cos_sim_tensor.item())
                    self.stat_sim_computed += 1
                    # Update counters in a thread-safe manner
                    with self._rx_lock:
                        self.number_of_neighbor_param_received += 1
                        self.stat_rx_msgs += 1
                else:
                    logging.info("Worker {} add_result_for_flock: using CPU path for accumulation.".format(self.worker_index))
                    # CPU path: compute cosine similarity using CPU snapshot
                    if (self.step_param_cpu is not None) and (self.step_param_cpu.numel() == self._total_len):
                        local_slice = self.step_param_cpu[idx]
                        neigh_slice = q_values.to(local_slice.dtype)
                        EPS = 1e-8
                        denom = local_slice.norm() * neigh_slice.norm() + EPS
                        if float(denom) > 0.0:
                            cos_raw = torch.dot(local_slice, neigh_slice) / denom
                            cos_raw = torch.clamp(cos_raw, min=0.9, max=1.0)
                            cos_sim = float((cos_raw - 0.9) / (1.0 - 0.9 + EPS))
                    else:
                        cos_sim = 0.0
                    self.stat_sim_computed += 1
                    # (3) accumulate neighbor's values and weights on CPU
                    with self._rx_lock:
                        self._rx_active.index_add_(0, idx.long(), q_values)
                        self.neighbor_total_weight_active[idx] += self.neighbor_weight
                        self.number_of_neighbor_param_received += 1
                        self.stat_rx_msgs += 1

                # (4) update staleness + utility via callback
                if callable(self._eval_cb):
                    # if sender_round % 10 == 0:
                    #     logging.info("Worker {} add_result_for_flock: calling eval_cb for sender {} round {}, cos_sim {:.4f}, self.number_of_neighbor_param_received {}".format(self.worker_index,worker_index,sender_round,cos_sim,self.number_of_neighbor_param_received))
                    try:
                        self._eval_cb(int(worker_index), int(sender_round), float(cos_sim))
                    except Exception:
                        logging.exception("eval callback failed in add_result_for_flock")
            finally:
                # —— 及时释放局部张量引用，降低 RSS 峰值 ——
                # 这些 del 只删除 Python 引用；真实内存释放取决于是否还有别的引用
                for _obj in (idx, q_values, q_indices):
                    try:
                        del _obj
                    except Exception:
                        pass

    # -------------------- Two-phase nonblocking merge: Stage (A) + Apply (B) --------------------
    def stage_merge_nonblocking(self, flatten_params: TensorBuffer) -> bool:
        """
        Phase-A (nonblocking): if new data exists and no in-flight merge,
        swap CPU dual buffers and launch pinned-CPU -> GPU async copy on a dedicated stream.
        Return True if a stage is initiated; otherwise False.
        """
        # no new data or in-flight merge exists
        if (self.number_of_neighbor_param_received == 0) or self._merge_pending:
            return False

        # swap CPU buffers; get ready snapshot
        with self._rx_lock:
            ready = self._rx_active
            self._rx_active, self._rx_standby = self._rx_standby, self._rx_active
            self._rx_active.zero_()

        # drain trigger queue
        try:
            if self.number_of_neighbor_param_received > 0:
                self.number_of_neighbor_param_received = 0
                self.total_neighbor_weight = 0.0
        except Exception:
            pass

        gpu_buf = flatten_params.buffer

        # CPU-only training path: directly add on CPU (no H2D)
        if (not self._use_cuda) or (not gpu_buf.is_cuda):
            gpu_buf.add_(ready.to(dtype=gpu_buf.dtype, copy=False))
            ready.zero_()
            self.stat_batch_swaps += 1
            return True

        # CUDA path: launch async H2D copy on the copy-stream; do NOT modify params here
        if (self._h2d_buf is None or
                self._h2d_buf.dtype != gpu_buf.dtype or
                self._h2d_buf.numel() != gpu_buf.numel() or
                self._h2d_buf.device != gpu_buf.device):
            self._h2d_buf = torch.empty_like(gpu_buf)

        with torch.cuda.stream(self._copy_stream):
            # ready must be pinned CPU
            self._h2d_buf.copy_(ready.view_as(self._h2d_buf), non_blocking=True)
            self._h2d_event.record(self._copy_stream)

        self._ready_inflight = ready
        self._merge_pending = True
        self.stat_batch_swaps += 1
        return True

    def apply_pending_merge(self, flatten_params: TensorBuffer) -> bool:
        """
        Phase-B (safe point on training stream): wait for the copy event then
        add the staged buffer into GPU params; zero the CPU source; clear the state.
        Return True if applied; otherwise False.
        """
        if not self._merge_pending:
            return False

        gpu_buf = flatten_params.buffer
        if (self._use_cuda and gpu_buf.is_cuda):
            torch.cuda.current_stream().wait_event(self._h2d_event)
            gpu_buf.add_(self._h2d_buf)
        else:
            # CPU-only fallback (should already be done in stage)
            pass

        if self._ready_inflight is not None:
            self._ready_inflight.zero_()
            self._ready_inflight = None

        self._merge_pending = False
        return True

    # -------------------- Backward-compatible aggregate (wraps Stage+Apply) --------------------
    # def aggregate_for_flock(self, compressor, selected_shapes, flatten_params):
    #     """
    #     Kept for compatibility. It will try to Stage then immediately Apply.
    #     Prefer calling stage_merge_nonblocking() in a merger thread and
    #     apply_pending_merge() at training safe points for real overlap.
    #     """
    #     staged = self.stage_merge_nonblocking(flatten_params)
    #     if staged:
    #         self.apply_pending_merge(flatten_params)
    #     # Pop one trigger item to keep old callers happy
    #     if self.flag_neighbor_result_received_dict_for_flock:
    #         neighbor_idx, sender_round = self.flag_neighbor_result_received_dict_for_flock.pop(0)
    #     else:
    #         neighbor_idx, sender_round = None, -1
    #     return neighbor_idx, 1.0, sender_round                    

    # file output implementation
    def aggregate_for_flock(self, compressor, selected_shapes, sync_buffer):
        self.aggregate_cnt += 1
        # logging.info("Worker {} aggregate_for_flock: called {}/{} times".format(self.worker_index,self.aggregate_time,self.timer.max_steps))

        if self.number_of_neighbor_param_received == 0:
            return

        ready = None
        try:
            with self._rx_lock:
                ready = self._rx_active
                ready_weight = self.neighbor_total_weight_active
                # swap buffers for next round
                self.neighbor_total_weight_active, self.neighbor_total_weight_standby = self.neighbor_total_weight_standby, self.neighbor_total_weight_active
                self.neighbor_total_weight_active.zero_()
                self._rx_active, self._rx_standby = self._rx_standby, self._rx_active
                self._rx_active.zero_()
                # reset counters
                self.number_of_neighbor_param_received = 0
                self.total_neighbor_weight = 0.0

            t0 = time.time()
            gpu_buf = sync_buffer["flatten_params"].buffer

            # CPU-only path (e.g., CPU training or no CUDA available)
            if (not self._use_cuda) or (not gpu_buf.is_cuda):
                add_vec_cpu = ready.to(dtype=gpu_buf.dtype, copy=False)  # 这里应该是加上，不是赋值
                add_w_vec_cpu = ready_weight.to(dtype=gpu_buf.dtype, copy=False)
                add_w_vec_cpu.add_(self.neighbor_weight)  # 加上自己的权重 0.5
                gpu_buf.add_(add_vec_cpu)
                gpu_buf.div_(add_w_vec_cpu.clamp_min_(1e-6))  # 归一化
                h2d_t = time.time() - t0
            else:
                # Ensure all GPU-side accumulations are finished before merging
                if self._accum_stream is not None:
                    self._accum_stream.synchronize()
                # Add local node's weight to the denominator accumulator (push-sum)
                with self._accum_lock:
                    if self._gpu_weight_accum is not None:
                        self._gpu_weight_accum.add_(float(self.neighbor_weight))
                    # (7) fuse accumulators into model (flatten_params) on GPU
                    gpu_buf.add_(self._gpu_buf_accum)
                    gpu_buf.div_(self._gpu_weight_accum.clamp_min_(1e-6))
                h2d_t = time.time() - t0

            # 统计
            self.stat_batch_swaps += 1
            self.stat_batch_merge_h2d_time += float(h2d_t)

            # 清空 ready 内容，避免旧数据叠加
            ready.zero_()
            ready_weight.zero_()
        finally:
            # —— 释放局部引用 ——
            try:
                del ready
            except NameError:
                pass

    def init_flatten_params_shapes(self):
        params, _shapes = get_data(self.param_groups, self.param_names, is_get_grad=False)
        # 1) 空/未 materialize 守卫（lazy 或顺序未就绪）
        if (params is None) or (len(params) == 0):
            logging.info("warning!!!!init_flatten_params_shapes: param list empty; delay shapes init.")
            return [], 0
        _total_len = int(sum(p.numel() for p in params))
        return _shapes, _total_len

    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]
        self.in_neighbor_idx_list = self.topology_manager.get_in_neighbor_idx_list(self.worker_index)
