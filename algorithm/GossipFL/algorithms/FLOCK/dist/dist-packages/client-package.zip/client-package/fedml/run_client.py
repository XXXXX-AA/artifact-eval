# run_client.py
import os
from decentralized_worker_manager import DecentralizedWorkerManager

if __name__ == "__main__":
    # 这些参数稍后可在 FedML Web UI 的 Hyperparams 里填写（平台会以 env/args 下发）
    rank        = int(os.getenv("RANK", os.getenv("FEDML_CLIENT_ID", "0")))
    world_size  = int(os.getenv("WORLD_SIZE", "4"))
    bootstrap   = os.getenv("BOOTSTRAP_ADDR", "tcp://<host>:<port>")
    compress    = float(os.getenv("COMPRESS_RATIO", "0.0"))

    mgr = DecentralizedWorkerManager(
        rank=rank,
        world_size=world_size,
        bootstrap=bootstrap,
        compress_ratio=compress,
        # …把你原来 main() 里传的参数照抄过来
    )
    mgr.run_sync()
