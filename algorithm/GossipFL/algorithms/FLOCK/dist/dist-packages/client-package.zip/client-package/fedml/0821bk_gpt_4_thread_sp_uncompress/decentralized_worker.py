import logging
import time
from copy import deepcopy
from utils.spill_queue_full_disk_0816 import SpillQueue
import torch
from torch import nn
import traceback
from mpi4py import MPI
import threading

from utils.timer import Timer
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from algorithms.baseDecent.decentralized_worker import BaseDecentralizedWorker
from .message_define import MyMessage


class DecentralizedWorker(BaseDecentralizedWorker):
    def __init__(self, worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics):
        """
            The `compression` method should be specified in `args`.
        """
        self.worker_index = worker_index
        self.spill_queue = SpillQueue(self.worker_index)
        self.topology_manager = topology_manager
        self.refresh_gossip_info()
        #===========================================================================
        super().__init__(worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics)

        # =================================================
        # Specilaized for SAPS_FL
        # ============================================================
        self.param_groups = self.model_trainer.param_groups
        self.param_names = self.model_trainer.param_names

        # will be initialized in init_neighbor_hat_params()
        self.neighbor_hat_params = None
        self.shapes = None

        # ---------------- 前移解压 + CPU 双缓冲 + 即时相似度 ----------------
        # flatten 形状与总长度
        params, _shapes = get_data(self.param_groups, self.param_names, is_get_grad=False)
        self.shapes = _shapes
        self._total_len = int(sum(p.numel() for p in params))

        # CPU 双缓冲
        self._rx_lock = threading.Lock()
        self._rx_buf_a = torch.zeros(self._total_len, dtype=torch.float32, device="cpu")
        self._rx_buf_b = torch.zeros_like(self._rx_buf_a)
        self._rx_active = self._rx_buf_a
        self._rx_standby = self._rx_buf_b

        # 版本/轮次管理
        self._merged_version_last = -1
        self._rx_version = 0  # add_result_for_flock 到达包打这个 version；swap 后自增

        # 训练步后记录的扁平参数快照（CPU）：由 manager 在 run_sync 内赋值
        self.step_param_cpu = None

        # 压缩器 & 即时评估回调（由 manager 注入）
        self._rx_comp = None
        self._eval_cb = None

        # 统计计数器
        self.stat_rx_msgs = 0
        self.stat_rx_elems = 0
        self.stat_batch_swaps = 0
        self.stat_batch_merge_h2d_bytes = 0
        self.stat_batch_merge_h2d_time = 0.0
        self.stat_sim_computed = 0  # 已计算的相似度条数

    def set_rx_compressor(self, compressor):
        """由 manager 调用，把 compressor 注入到 worker（用于本地前移解压）。"""
        self._rx_comp = compressor

    def set_eval_callback(self, cb):
        """
        由 manager 注入回调，用于在接收线程里即时完成：
          - 对称 staleness 衰减
          - self._update_neighbor_utility(...)
        cb: Callable(neighbor_idx: int, sender_round: int, cos_sim: float) -> None
        """
        self._eval_cb = cb

    def aggregate(self, compressor, selected_shapes, gossip_info):
        # 已不使用；保留原函数签名以兼容其他路径
        start_time = time.time()
        for neighbor_idx in self.in_neighbor_idx_list:
            msg_params = self.worker_result_dict[neighbor_idx]
            compressor.uncompress(
                msg_params, gossip_info[neighbor_idx],
                self.neighbor_hat_params["memory"],
                selected_shapes, self.shapes,
                self.device
            )
        self.worker_result_dict = {}
        end_time = time.time()
        logging.debug("aggregate time cost: %.3f" % (end_time - start_time))

    # ---------------- 核心改动 1：接收线程立即解压 + 与 step_param_cpu 计算相似度 + CPU 累加 + 立刻更新效用 ----------------
    def add_result_for_flock(self, worker_index, sender_round, updated_information):
        """
        1) CPU 解压 → 返回 (q_values, q_indices)
        2) 与 step_param_cpu 计算相似度
        3) 将 0.5 * q_values 累加到 CPU 活动缓冲（_rx_active）
        4) 立刻回调 _eval_cb 做 staleness+utility 更新
        5) 标记已接收（用于触发 swap+merge）
        """
        logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
            self.worker_index, worker_index, sender_round))

        if self._rx_comp is None:
            raise RuntimeError("RX compressor not set. Call set_rx_compressor() in manager before training.")

        # —— 解压到 CPU（门面 API）——
        q_values = q_indices = idx = local_slice = neigh_slice = inc = None
        try:
            q_values, q_indices = self._rx_comp.decode_sparse_msg(updated_information, self.shapes)

            # 2) 计算相似度（若尚未记录，保守置 1.0）
            cos_sim = 1.0
            if (self.step_param_cpu is not None) and (self.step_param_cpu.numel() == self._total_len):
                idx = q_indices.to(dtype=torch.long)  # 索引保证 long
                local_slice = self.step_param_cpu[idx]
                neigh_slice = q_values.to(local_slice.dtype)
                EPS = 1e-8
                denom = local_slice.norm() * neigh_slice.norm() + EPS
                if float(denom) > 0.0:
                    cos_raw = torch.dot(local_slice, neigh_slice) / denom
                    COS_MIN, COS_MAX = 0.9, 1.0
                    cos_raw = torch.clamp(cos_raw, min=COS_MIN, max=COS_MAX)
                    cos_sim = float((cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS))
            else:
                cos_sim = 1.0
            self.stat_sim_computed += 1

            # 3) CPU 累加（权重 0.5）
            if idx is None:
                idx = q_indices.to(dtype=torch.long)
            inc = (0.5 * q_values).to(self._rx_active.dtype)
            with self._rx_lock:
                self._rx_active.index_add_(0, idx, inc)

            # 4) 立刻完成 staleness + utility 更新
            if callable(self._eval_cb):
                try:
                    self._eval_cb(int(worker_index), int(sender_round), float(cos_sim))
                except Exception:
                    logging.exception("eval callback failed in add_result_for_flock")

            # 5) 通知训练线程（仅用于触发 swap+merge 的时机）
            self.flag_neighbor_result_received_dict_for_flock.append((worker_index, sender_round))

            # 统计
            self.stat_rx_msgs += 1
            self.stat_rx_elems += int(q_indices.numel())

        finally:
            # —— 及时释放局部张量引用，降低 RSS 峰值 —— 
            # 这些 del 只删除 Python 引用；真实内存释放取决于是否还有别的引用
            try: del idx
            except NameError: pass
            try: del inc
            except NameError: pass
            try: del local_slice
            except NameError: pass
            try: del neigh_slice
            except NameError: pass
            try: del q_values
            except NameError: pass
            try: del q_indices
            except NameError: pass

    # def add_result_for_flock(self, worker_index, sender_round, updated_information):
    #     """
    #     1) CPU 上用 compressor_fn.uncompress 展开 indices；得到 (q_values, q_indices)（均在 CPU）
    #     2) 与最近一次 train_one_step 后记录的 self.step_param_cpu 在相同 index 处计算余弦相似度（CPU）
    #     3) 将 0.5 * q_values index_add_ 到 CPU 活动缓冲（_rx_active），用于下一轮批量合并
    #     4) 立刻调用回调 _eval_cb(neighbor_idx, sender_round, cos_sim) 完成 staleness & utility 更新
    #     5) 将 (sender, round) 记到 flag 队列，训练线程只负责触发 swap+merge，不再做逐条 add / 计算相似度
    #     """
    #     logging.debug("Worker {} add_result_for_flock: sender={}, round={}".format(
    #         self.worker_index, worker_index, sender_round))

    #     if self._rx_comp is None:
    #         raise RuntimeError("RX compressor not set. Call set_rx_compressor() in manager before training.")

    #     # 取消息：CPU 张量
    #     # values_cpu = updated_information.get(MyMessage.MSG_ARG_KEY_SPARSE_PARAMS_1)
    #     # indices_cpu = updated_information.get(MyMessage.MSG_ARG_KEY_SPARSE_INDEX_1)
    #     # sel_shapes  = updated_information.get(MyMessage.MSG_ARG_KEY_SELECTED_SHAPES)
    #     # selected_shapes = sel_shapes.tolist() if sel_shapes is not None else None

    #     q_values, q_indices = self._rx_comp.decode_sparse_msg(updated_information, self.shapes)


    #     # 2) 用当前 step_param_cpu 计算相似度（若尚未记录，保守置 1.0）
    #     cos_sim = 1.0
    #     if (self.step_param_cpu is not None) and (self.step_param_cpu.numel() == self._total_len):
    #         idx = q_indices.to(dtype=torch.long, copy=False)     # 避免新拷贝
    #         local_slice = self.step_param_cpu[idx]
    #         neigh_slice = q_values.to(local_slice.dtype, copy=False)
    #         EPS = 1e-8
    #         denom = local_slice.norm() * neigh_slice.norm() + EPS
    #         if float(denom) > 0.0:
    #             cos_raw = torch.dot(local_slice, neigh_slice) / denom
    #             COS_MIN, COS_MAX = 0.9, 1.0
    #             cos_raw = torch.clamp(cos_raw, min=COS_MIN, max=COS_MAX)
    #             cos_sim = float((cos_raw - COS_MIN) / (COS_MAX - COS_MIN + EPS))
    #     self.stat_sim_computed += 1

    #     # 3) CPU 累加（权重 0.5）
    #     with self._rx_lock:
    #         self._rx_active.index_add_(0, q_indices.long(), (0.5 * q_values).to(self._rx_active.dtype))

    #     # 4) 立刻完成“对称 staleness 衰减 + 邻居效用更新”
    #     if callable(self._eval_cb):
    #         try:
    #             self._eval_cb(int(worker_index), int(sender_round), float(cos_sim))
    #         except Exception:
    #             logging.exception("eval callback failed in add_result_for_flock")

    #     # 5) 通知训练线程（仅用于触发 swap+merge 的时机）
    #     self.flag_neighbor_result_received_dict_for_flock.append((worker_index, sender_round))

    #     # 统计
    #     self.stat_rx_msgs += 1
    #     self.stat_rx_elems += int(q_indices.numel())

    # ---------------- 核心改动 2：训练线程——每轮一次 swap+merge；不再逐条 GPU index_add_ ----------------
    def aggregate_for_flock(self, compressor, selected_shapes, flatten_params):
        """
        每轮仅做一次 swap+merge（把 CPU 活动缓冲一次性合入 GPU），
        不再逐条 GPU index_add_；增量在下一轮生效。
        """
        if not self.flag_neighbor_result_received_dict_for_flock:
            return None, 1.0, -1

        # 每轮仅在第一次到达时做一次 swap+merge
        if self._merged_version_last < (self._rx_version - 1):
            ready = None
            add_vec = None
            try:
                with self._rx_lock:
                    ready = self._rx_active
                    self._rx_active, self._rx_standby = self._rx_standby, self._rx_active
                    self._rx_active.zero_()
                    this_merge_version = self._rx_version
                    self._rx_version += 1

                # 合并（H2D + add_）
                t0 = time.time()
                gpu_buf = flatten_params.buffer
                add_vec = ready.to(device=gpu_buf.device, dtype=gpu_buf.dtype)
                gpu_buf.add_(add_vec)
                h2d_t = time.time() - t0

                # 统计
                self._merged_version_last = this_merge_version
                self.stat_batch_swaps += 1
                self.stat_batch_merge_h2d_bytes += int(add_vec.numel() * add_vec.element_size())
                self.stat_batch_merge_h2d_time += float(h2d_t)

                # 清空 ready 内容，避免旧数据叠加
                ready.zero_()
            finally:
                # —— 释放局部引用 —— 
                try: del add_vec
                except NameError: pass
                try: del ready
                except NameError: pass

        # 弹出一条，仅为“消费队列”；返回值不再被上层使用
        neighbor_idx, sender_round = self.flag_neighbor_result_received_dict_for_flock.popleft()
        return neighbor_idx, 1.0, sender_round


    def init_neighbor_hat_params(self):
        params, self.shapes = get_data(
            self.param_groups, self.param_names, is_get_grad=False
        )
        flatten_params = TensorBuffer(params)
        flatten_params.buffer = flatten_params.buffer * 0.5
        self.neighbor_hat_params = {"memory": deepcopy(flatten_params)}

    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]
        self.in_neighbor_idx_list = self.topology_manager.get_in_neighbor_idx_list(self.worker_index)
