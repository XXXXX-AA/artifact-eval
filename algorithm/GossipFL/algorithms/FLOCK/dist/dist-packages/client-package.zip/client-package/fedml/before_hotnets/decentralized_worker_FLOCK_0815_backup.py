import logging
import time
from copy import deepcopy

import torch
from torch import nn
import traceback
import spill_queue
from mpi4py import MPI

from utils.timer import Timer
# from fedml_api.utils.timer_with_cuda import Timer
from utils.data_utils import (
    get_data,
    apply_gradient
)
from utils.tensor_buffer import (
    TensorBuffer
)

from algorithms.baseDecent.decentralized_worker import BaseDecentralizedWorker

class DecentralizedWorker(BaseDecentralizedWorker):
    def __init__(self, worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics):
        """
            The `compression` method should be specified in `args`.
        """
        self.worker_index = worker_index
        self.topology_manager = topology_manager
        self.refresh_gossip_info()
        #===========================================================================
        super().__init__(worker_index, topology_manager, train_data_global, test_data_global, train_data_num,
                 train_data_local_dict, test_data_local_dict, train_data_local_num_dict, worker_number, 
                 device, model, args, model_trainer, timer, metrics)

        # =================================================
        # Specilaized for SAPS_FL
        # ============================================================
        self.param_groups = self.model_trainer.param_groups
        self.param_names = self.model_trainer.param_names
        # self.neighbors_info = self.topology_manager.topology
        # self.gossip_info = self.topology_manager.topology[self.worker_index]

        # will be initialized in init_neighbor_hat_params()
        self.neighbor_hat_params = None
        self.shapes = None
        # self.init_neighbor_hat_params()


    # def update_cluster(self, neighbor_loss, neighbor_cluster_name, neighbor_cluster_neighbors, neighbor_index):
    #     """
    #     Update cluster information based on neighbor's loss and cluster data.
    #     """
    #     if neighbor_cluster_name is None:
    #         # Generate a new cluster name using hash of sorted indices
    #         new_cluster_name = hash(tuple(sorted([self.worker_index, neighbor_index])))
    #         self.cluster_name = new_cluster_name
    #         self.cluster_neighbors[self.worker_index] = 1
    #         self.cluster_neighbors[neighbor_index] = 1
    #     elif self.loss is not None and neighbor_loss < self.loss:
    #         # Update to neighbor's cluster
    #         self.cluster_name = neighbor_cluster_name
    #         self.cluster_neighbors = neighbor_cluster_neighbors[:]


    def aggregate(self, compressor, selected_shapes, gossip_info):
        start_time = time.time()
        model_list = []
        training_num = 0

        for neighbor_idx in self.in_neighbor_idx_list:

            msg_params = self.worker_result_dict[neighbor_idx]
            compressor.uncompress(msg_params, gossip_info[neighbor_idx],
                self.neighbor_hat_params["memory"],
                selected_shapes, self.shapes,
                self.device
            )

        logging.debug("len of self.in_neighbor_idx_list[{}] = {}".format(
            self.worker_index, str(len(self.in_neighbor_idx_list))))
        logging.debug("len of self.worker_result_dict[{}] = {}".format(
            self.worker_index, str(len(self.worker_result_dict))))
        # clear dict for saving memory
        self.worker_result_dict = {}

        end_time = time.time()
        logging.debug("aggregate time cost: %.3f" % (end_time - start_time))
        # return averaged_params

    # ==============================================================================
    # Specilaized for SAPS_FL


    # for flock
    def add_result_for_flock(self, worker_index, sender_round, updated_information):
        logging.debug("Worker {} received and add_result_for_flock: worker_index = {}".format(self.worker_index,worker_index))
        self.worker_result_dict[(worker_index, sender_round)] = updated_information
        self.flag_neighbor_result_received_dict_for_flock.append((worker_index, sender_round))
        logging.debug("Worker {} content of self.worker_result_dict[{}]".format(self.worker_index,str(self.worker_result_dict)))


    
    # for flock
    def aggregate_for_flock(self, compressor, selected_shapes,flatten_params):
        # start_time = time.time()
        model_list = []
        training_weights = 0


        if self.flag_neighbor_result_received_dict_for_flock:
            # Get model params
            # params, _ = get_data(
            #     self.param_groups, self.param_names, is_get_grad=False
            # )
            # flatten_params = TensorBuffer(params)
            # before optimization
            # flatten_params.buffer = flatten_params.buffer * 0.5
            # self.neighbor_hat_params = {"memory": deepcopy(flatten_params),}
            # after optimization
            # flatten_params.buffer.mul_(0.5)
            self.neighbor_hat_params = {"memory": flatten_params}

            neighbor_idx, sender_round = self.flag_neighbor_result_received_dict_for_flock.popleft()
            logging.debug(str(self.worker_index)+" begins to aggregate, with flag_neighbor_result_received_dict_for_flock is not empty "+str(neighbor_idx))
            logging.debug("Worker {} content of self.worker_result_dict[{}]".format(self.worker_index,str(self.worker_result_dict)))
            msg_params = self.worker_result_dict[(neighbor_idx, sender_round)]
            del self.worker_result_dict[(neighbor_idx, sender_round)]
            _,cos_sim = compressor.uncompress(msg_params, 0.5,
                self.neighbor_hat_params["memory"],
                selected_shapes, self.shapes,
                self.device
            )

            logging.debug("len of self.in_neighbor_idx_list[{}] = {}".format(
                self.worker_index, str(len(self.in_neighbor_idx_list))))
            logging.debug("len of self.worker_result_dict[{}] = {}".format(
                self.worker_index, str(len(self.worker_result_dict))))
            # clear dict for saving memory
            # self.worker_result_dict = {}

            # end_time = time.time()
            # logging.info("aggregate time cost: %.3f" % (end_time - start_time))
            return neighbor_idx, cos_sim,sender_round
            
            
        





    def init_neighbor_hat_params(self):
        params, self.shapes = get_data(
            self.param_groups, self.param_names, is_get_grad=False
        )
        flatten_params = TensorBuffer(params)
        # flatten_params.buffer = flatten_params.buffer * self.gossip_info[self.worker_index]
        flatten_params.buffer = flatten_params.buffer * 0.5
        # init the neighbor_params.
        self.neighbor_hat_params = {
            "memory": deepcopy(flatten_params),
            }
        # logging.debug("###################################")
        # logging.debug("self.neighbor_hat_params is on device: {}".format(
        #     self.neighbor_hat_params["memory"].buffer.device
        # ))
        # logging.debug("###################################")

    def refresh_gossip_info(self):
        self.neighbors_info = self.topology_manager.topology
        self.gossip_info = self.topology_manager.topology[self.worker_index]
        self.in_neighbor_idx_list = self.topology_manager.get_in_neighbor_idx_list(self.worker_index)









